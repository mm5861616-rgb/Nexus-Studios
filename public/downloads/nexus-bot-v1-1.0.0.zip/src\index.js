import "dotenv/config";
import {
  Client,
  Events,
  GatewayIntentBits,
  MessageFlags,
  PermissionFlagsBits,
} from "discord.js";
import { handleTicketInteraction } from "./ticket-system.js";

const token = process.env.DISCORD_TOKEN;

if (!token) {
  throw new Error("DISCORD_TOKEN fehlt. Lege discord/nexus-bot/.env anhand der .env.example an.");
}

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

const commandPermissions = {
  clear: PermissionFlagsBits.ManageMessages,
  kick: PermissionFlagsBits.KickMembers,
  ban: PermissionFlagsBits.BanMembers,
  timeout: PermissionFlagsBits.ModerateMembers,
  untimeout: PermissionFlagsBits.ModerateMembers,
};

const commandList = [
  "`/commands` – zeigt diese Befehlsübersicht",
  "`/clear anzahl` – löscht 1 bis 100 Nachrichten, die höchstens 14 Tage alt sind",
  "`/kick mitglied [grund]` – entfernt ein Mitglied vom Server",
  "`/ban mitglied [grund]` – bannt ein Mitglied vom Server",
  "`/timeout mitglied minuten [grund]` – Timeout von 1 bis 40.320 Minuten",
  "`/untimeout mitglied [grund]` – hebt einen bestehenden Timeout auf",
  "`/ticket-panel kanal support-rolle [ticket-kategorie]` – erstellt ein privates Ticket-Panel",
];

function makeAuditReason(interaction) {
  const reason = interaction.options.getString("grund")?.trim() || "Kein Grund angegeben";
  return `${reason} | Ausgeführt von ${interaction.user.tag}`;
}

async function rejectMissingPermission(interaction, permission) {
  if (interaction.memberPermissions?.has(permission)) return false;
  await interaction.reply({
    content: "Dir fehlt die erforderliche Discord-Berechtigung für diesen Befehl.",
    flags: MessageFlags.Ephemeral,
  });
  return true;
}

async function getModerationTarget(interaction) {
  const member = interaction.options.getMember("mitglied");
  if (!member) {
    await interaction.editReply("Das Mitglied konnte auf diesem Server nicht gefunden werden.");
    return null;
  }
  if (member.id === interaction.user.id) {
    await interaction.editReply("Du kannst diese Moderationsaktion nicht gegen dich selbst ausführen.");
    return null;
  }
  if (member.id === client.user.id) {
    await interaction.editReply("Der Bot kann keine Moderationsaktion gegen sich selbst ausführen.");
    return null;
  }
  return member;
}

async function handleModerationCommand(interaction) {
  const permission = commandPermissions[interaction.commandName];
  if (await rejectMissingPermission(interaction, permission)) return;

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  if (interaction.commandName === "clear") {
    const amount = interaction.options.getInteger("anzahl", true);
    if (!interaction.channel?.isTextBased() || !("bulkDelete" in interaction.channel)) {
      await interaction.editReply("Dieser Befehl funktioniert nur in einem Textkanal.");
      return;
    }
    const deleted = await interaction.channel.bulkDelete(amount, true);
    await interaction.editReply(`${deleted.size} Nachricht(en) gelöscht. Nachrichten älter als 14 Tage werden von Discord übersprungen.`);
    return;
  }

  const member = await getModerationTarget(interaction);
  if (!member) return;

  const reason = makeAuditReason(interaction);

  if (interaction.commandName === "kick") {
    if (!member.kickable) {
      await interaction.editReply("Der Bot kann dieses Mitglied wegen seiner Rollenposition oder fehlender Rechte nicht kicken.");
      return;
    }
    await member.kick(reason);
    await interaction.editReply(`${member.user.tag} wurde vom Server entfernt.`);
    return;
  }

  if (interaction.commandName === "ban") {
    if (!member.bannable) {
      await interaction.editReply("Der Bot kann dieses Mitglied wegen seiner Rollenposition oder fehlender Rechte nicht bannen.");
      return;
    }
    await member.ban({ reason, deleteMessageSeconds: 0 });
    await interaction.editReply(`${member.user.tag} wurde vom Server gebannt.`);
    return;
  }

  if (interaction.commandName === "timeout") {
    if (!member.moderatable) {
      await interaction.editReply("Der Bot kann dieses Mitglied wegen seiner Rollenposition oder fehlender Rechte nicht timeouten.");
      return;
    }
    const minutes = interaction.options.getInteger("minuten", true);
    await member.timeout(minutes * 60 * 1000, reason);
    await interaction.editReply(`${member.user.tag} hat einen Timeout für ${minutes} Minute(n) erhalten.`);
    return;
  }

  if (interaction.commandName === "untimeout") {
    if (!member.moderatable) {
      await interaction.editReply("Der Bot kann den Timeout dieses Mitglieds wegen seiner Rollenposition oder fehlender Rechte nicht ändern.");
      return;
    }
    if (!member.isCommunicationDisabled()) {
      await interaction.editReply(`${member.user.tag} hat aktuell keinen Timeout.`);
      return;
    }
    await member.timeout(null, reason);
    await interaction.editReply(`Der Timeout von ${member.user.tag} wurde aufgehoben.`);
  }
}

client.once(Events.ClientReady, (readyClient) => {
  console.log(`Nexus Bot V1 ist als ${readyClient.user.tag} online.`);
});

client.on(Events.InteractionCreate, async (interaction) => {
  if (await handleTicketInteraction(interaction)) return;
  if (!interaction.isChatInputCommand()) return;

  if (interaction.commandName === "commands") {
    await interaction.reply({
      content: `**Nexus Bot V1 – Befehle**\n${commandList.join("\n")}\n\nModerationsbefehle sind auf Discord-Berechtigte beschränkt.`,
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  try {
    await handleModerationCommand(interaction);
  } catch (error) {
    console.error(`Fehler bei /${interaction.commandName}:`, error);
    const message = "Der Befehl ist fehlgeschlagen. Prüfe Bot-Rechte, Rollenposition und Serverprotokoll.";
    if (interaction.deferred || interaction.replied) {
      await interaction.editReply(message);
    } else {
      await interaction.reply({ content: message, flags: MessageFlags.Ephemeral });
    }
  }
});

client.on(Events.Error, (error) => {
  console.error("Discord-Verbindungsfehler:", error);
});

await client.login(token);

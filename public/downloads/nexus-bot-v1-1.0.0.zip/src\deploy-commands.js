import "dotenv/config";
import { REST, Routes } from "discord.js";
import { commands } from "./commands.js";

const { DISCORD_TOKEN, DISCORD_CLIENT_ID, DISCORD_GUILD_ID } = process.env;

if (!DISCORD_TOKEN || !DISCORD_CLIENT_ID || !DISCORD_GUILD_ID) {
  throw new Error("DISCORD_TOKEN, DISCORD_CLIENT_ID und DISCORD_GUILD_ID müssen in .env gesetzt sein.");
}

const rest = new REST({ version: "10" }).setToken(DISCORD_TOKEN);

await rest.put(Routes.applicationGuildCommands(DISCORD_CLIENT_ID, DISCORD_GUILD_ID), {
  body: commands,
});

console.log(`Nexus Bot V1: ${commands.length} Slash-Befehle auf Server ${DISCORD_GUILD_ID} registriert.`);

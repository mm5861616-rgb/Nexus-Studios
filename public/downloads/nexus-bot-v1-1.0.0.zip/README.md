# Nexus Bot V1

Nexus Bot V1 is a **script only**: Discord.js source code for `/commands` and moderation slash commands. It is not a bot-hosting service, and Nexus Development does not run the bot for you. A compatible runtime must execute this script and keep its Discord connection alive. It does not need privileged gateway intents and does not store a moderation database.

### Using a bot-hosting script platform

Use this package on a platform only if it supports running custom Node.js 20+ / Discord.js 14 scripts, keeping the process online, and registering custom Discord slash commands. An input for a Discord token by itself is not enough to install or run this script. You also need to register commands once using the application's client ID and a server ID; the included `deploy-commands` utility does this for a test server.

GhostBot compatibility has not been verified. Before using it there, confirm with GhostBot that it accepts and executes custom Discord.js scripts and allows slash-command registration. Do not paste a real token into an incompatible product or share it with anyone.

## Requirements

- Node.js 20 or newer
- A Discord application and bot created in the [Discord Developer Portal](https://discord.com/developers/applications)
- A Discord server where you can add the bot and grant its permissions

## 1. Create the Discord application and bot

1. In the Developer Portal, create an application named **Nexus Bot V1**.
2. Open **Bot**, create the bot user, and copy its token. Keep the token private; anyone with it can control your bot. If it is exposed, reset it in the Developer Portal immediately.
3. In **General Information**, copy the **Application ID**. This is the client ID used below.
4. In Discord, enable Developer Mode under **User Settings → Advanced**, then right-click your test server and copy its server ID.
5. Under **OAuth2 → URL Generator**, select the `bot` and `applications.commands` scopes. Grant only these bot permissions:
   - View Channels
   - Send Messages
   - Use Application Commands
   - Embed Links
   - Read Message History
   - Manage Channels
   - Manage Messages
   - Kick Members
   - Ban Members
   - Moderate Members
6. Open the generated URL and add the bot to your server. Do not grant Administrator.
7. In **Server Settings → Roles**, place the bot's role above the roles it needs to moderate. Discord will still prevent the bot from moderating the server owner or members above its role.

## 2. Install and configure

Open a terminal in this `nexus-bot` folder and install the dependencies:

```sh
npm install
```

Create a local `.env` file from the example.

PowerShell:

```powershell
Copy-Item .env.example .env
```

macOS/Linux:

```sh
cp .env.example .env
```

Edit `.env` and fill in the values:

```dotenv
DISCORD_TOKEN=paste_your_bot_token_here
DISCORD_CLIENT_ID=your_application_id
DISCORD_GUILD_ID=your_test_server_id
```

The token belongs only in this local `.env` file. Do not put it in website code, screenshots, chat messages, Git commits, or public repositories. `.env` is ignored by Git. Never replace or publish `.env.example` with real credentials.

## 3. Register commands and start the bot

Register the slash commands in the server specified by `DISCORD_GUILD_ID`:

```sh
npm run deploy-commands
```

Guild commands normally appear right away. Start the bot:

```sh
npm start
```

Keep the process running on your computer or host. The bot is not hosted by the Nexus website. To stop it, press `Ctrl+C`. If you change the command definitions in `src/commands.js`, run `npm run deploy-commands` again.

## Commands

| Command | Permission | Description |
| --- | --- | --- |
| `/commands` | None | Shows the command list privately to the person who ran it. |
| `/clear anzahl` | Manage Messages | Deletes 1–100 recent messages. Discord bulk deletion skips messages older than 14 days. |
| `/kick mitglied [grund]` | Kick Members | Kicks a member and records the reason in the audit log. |
| `/ban mitglied [grund]` | Ban Members | Bans a member and records the reason in the audit log. |
| `/timeout mitglied minuten [grund]` | Moderate Members | Sets a timeout from 1 minute up to Discord's 28-day limit. |
| `/untimeout mitglied [grund]` | Moderate Members | Removes an active timeout. |
| `/ticket-panel kanal support-rolle [ticket-kategorie]` | Manage Server | Posts a panel for private support, bug-report, and other-request tickets. |

Discord enforces the command permissions as well as the bot's own permissions and role hierarchy. Failed API operations are logged in the terminal; the bot responds with an error rather than reporting a successful moderation action.

## Ticket system

Run `/ticket-panel kanal:#support support-rolle:@Support` and optionally select a category for ticket channels. The bot posts three buttons: Support, Bug melden, and Sonstige Anfrage. Each button creates a private channel for the member, configured support role, and bot. A member can have only one open ticket at a time.

The ticket creator, a member of the selected support role, or a server manager can close a ticket. Closing it disables the creator's ability to send messages and keeps the channel as a read-only record. The script does not create transcripts or automatically delete ticket channels; administrators can remove old channels manually.

To add the ticket feature to another Discord.js v14 bot, copy `src/ticket-system.js` into its source folder, add `ticketPanelCommand` to the array of commands before serializing them, and call `handleTicketInteraction(interaction)` before filtering interactions to chat-input commands. The separate **Nexus Ticket System Script** download includes the integration steps.

## Troubleshooting

- **Commands do not appear:** check `DISCORD_CLIENT_ID` and `DISCORD_GUILD_ID`, then run `npm run deploy-commands` again.
- **Missing Access/permissions:** check the bot's server permissions and move its role above the target member's role.
- **Invalid token / login failure:** create or reset the token in the Developer Portal and update only the local `.env` file.

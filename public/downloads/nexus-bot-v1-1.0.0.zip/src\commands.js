import { PermissionFlagsBits, SlashCommandBuilder } from "discord.js";
import { ticketPanelCommand } from "./ticket-system.js";

export const commands = [
  new SlashCommandBuilder()
    .setName("commands")
    .setDescription("Zeigt die verfügbaren Nexus-Bot-Befehle."),
  new SlashCommandBuilder()
    .setName("clear")
    .setDescription("Löscht bis zu 100 aktuelle Nachrichten in diesem Kanal.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addIntegerOption((option) =>
      option
        .setName("anzahl")
        .setDescription("Anzahl der Nachrichten (1 bis 100)")
        .setMinValue(1)
        .setMaxValue(100)
        .setRequired(true),
    ),
  new SlashCommandBuilder()
    .setName("kick")
    .setDescription("Entfernt ein Mitglied vom Server.")
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
    .addUserOption((option) =>
      option.setName("mitglied").setDescription("Zu entfernendes Mitglied").setRequired(true),
    )
    .addStringOption((option) =>
      option.setName("grund").setDescription("Grund für den Kick").setMaxLength(500),
    ),
  new SlashCommandBuilder()
    .setName("ban")
    .setDescription("Bannt ein Mitglied vom Server.")
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addUserOption((option) =>
      option.setName("mitglied").setDescription("Zu bannendes Mitglied").setRequired(true),
    )
    .addStringOption((option) =>
      option.setName("grund").setDescription("Grund für den Bann").setMaxLength(500),
    ),
  new SlashCommandBuilder()
    .setName("timeout")
    .setDescription("Schaltet ein Mitglied vorübergehend stumm.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption((option) =>
      option.setName("mitglied").setDescription("Stummzuschaltendes Mitglied").setRequired(true),
    )
    .addIntegerOption((option) =>
      option
        .setName("minuten")
        .setDescription("Dauer in Minuten (1 bis 40320)")
        .setMinValue(1)
        .setMaxValue(40320)
        .setRequired(true),
    )
    .addStringOption((option) =>
      option.setName("grund").setDescription("Grund für den Timeout").setMaxLength(500),
    ),
  new SlashCommandBuilder()
    .setName("untimeout")
    .setDescription("Hebt den Timeout eines Mitglieds auf.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption((option) =>
      option.setName("mitglied").setDescription("Mitglied, dessen Timeout aufgehoben wird").setRequired(true),
    )
    .addStringOption((option) =>
      option.setName("grund").setDescription("Grund für die Aufhebung").setMaxLength(500),
    ),
  ticketPanelCommand,
].map((command) => command.toJSON());

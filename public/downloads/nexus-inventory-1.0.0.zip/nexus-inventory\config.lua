Config = {}

Config.Command = "nexusinventory"
Config.DefaultKey = "F3"
Config.SlotCount = 50
Config.RefreshInterval = 750
Config.DropCooldown = 750
Config.DropLabel = "Nexus"

Config.Categories = {
    "Verbrauch",
    "Ausrüstung",
    "Materialien",
    "Sonstiges",
}

Config.ItemCategories = {
    water = "Verbrauch",
    sandwich = "Verbrauch",
    bread = "Verbrauch",
    bandage = "Verbrauch",
    medikit = "Verbrauch",
    firstaid = "Verbrauch",
    phone = "Ausrüstung",
    radio = "Ausrüstung",
    lockpick = "Ausrüstung",
    repairkit = "Ausrüstung",
    metalscrap = "Materialien",
    copper = "Materialien",
    plastic = "Materialien",
    iron = "Materialien",
    steel = "Materialien",
}

Config.ItemRarities = {}

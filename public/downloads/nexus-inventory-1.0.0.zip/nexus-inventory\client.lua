local isOpen = false
local pendingDrop = false

local function notify(message)
    SendNUIMessage({
        action = "notice",
        message = message,
    })
end

local function getInventorySnapshot()
    if GetResourceState("ox_inventory") ~= "started" then
        return nil, "ox_inventory ist nicht gestartet."
    end

    local success, items = pcall(function()
        return exports.ox_inventory:GetPlayerItems()
    end)

    if not success or type(items) ~= "table" then
        return nil, "Dein ox_inventory ist noch nicht bereit."
    end

    local weightOk, weight = pcall(function()
        return exports.ox_inventory:GetPlayerWeight()
    end)
    local maxWeightOk, maxWeight = pcall(function()
        return exports.ox_inventory:GetPlayerMaxWeight()
    end)

    if not weightOk or not maxWeightOk then
        return nil, "Das Gewicht konnte nicht von ox_inventory geladen werden."
    end

    local slots = {}
    for slot, item in pairs(items) do
        if type(item) == "table" and item.name and (item.count or item.amount) then
            local itemSlot = tonumber(item.slot) or tonumber(slot)
            if itemSlot then
                slots[#slots + 1] = {
                    slot = itemSlot,
                    name = tostring(item.name),
                    label = tostring(item.label or item.name),
                    description = tostring(item.description or ""),
                    count = tonumber(item.count or item.amount) or 0,
                    weight = tonumber(item.weight) or 0,
                    category = Config.ItemCategories[item.name] or "Sonstiges",
                    rarity = Config.ItemRarities[item.name] or "common",
                    usable = item.close ~= false,
                }
            end
        end
    end

    table.sort(slots, function(a, b)
        return a.slot < b.slot
    end)

    return {
        items = slots,
        weight = tonumber(weight) or 0,
        maxWeight = tonumber(maxWeight) or 0,
        slotCount = Config.SlotCount,
    }
end

local function refreshInventory()
    if not isOpen then return end

    local snapshot, err = getInventorySnapshot()
    if not snapshot then
        notify(err)
        return
    end

    SendNUIMessage({
        action = "inventory",
        inventory = snapshot,
    })
end

local function closeInventory()
    if not isOpen then return end

    isOpen = false
    SetNuiFocus(false, false)
    SendNUIMessage({ action = "close" })
end

local function openInventory()
    if isOpen then
        closeInventory()
        return
    end

    local snapshot, err = getInventorySnapshot()
    if not snapshot then
        print(("[nexus-inventory] %s"):format(err))
        return
    end

    isOpen = true
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = "open",
        inventory = snapshot,
    })
end

RegisterCommand(Config.Command, openInventory, false)
RegisterKeyMapping(Config.Command, "Nexus Inventory öffnen/schließen", "keyboard", Config.DefaultKey)

RegisterNUICallback("close", function(_, callback)
    closeInventory()
    callback({ ok = true })
end)

RegisterNUICallback("refresh", function(_, callback)
    refreshInventory()
    callback({ ok = true })
end)

RegisterNUICallback("useItem", function(data, callback)
    local slot = tonumber(data and data.slot)
    if not isOpen or not slot or slot < 1 or slot % 1 ~= 0 then
        callback({ ok = false, error = "Ungültiger Inventar-Slot." })
        return
    end

    local success, err = pcall(function()
        exports.ox_inventory:useSlot(slot)
    end)

    if not success then
        print(("[nexus-inventory] Item in Slot %s konnte nicht benutzt werden: %s"):format(slot, err))
        callback({ ok = false, error = "Das Item konnte nicht benutzt werden." })
        return
    end

    callback({ ok = true })
    SetTimeout(350, refreshInventory)
end)

RegisterNUICallback("dropItem", function(data, callback)
    local slot = tonumber(data and data.slot)
    if not isOpen or not slot or slot < 1 or slot % 1 ~= 0 then
        callback({ ok = false, error = "Ungültiger Inventar-Slot." })
        return
    end

    if pendingDrop then
        callback({ ok = false, error = "Bitte warte, bis die letzte Aktion abgeschlossen ist." })
        return
    end

    pendingDrop = true
    TriggerServerEvent("nexus-inventory:server:dropItem", slot)
    callback({ ok = true })
end)

RegisterNetEvent("nexus-inventory:client:dropResult", function(success, message)
    pendingDrop = false
    notify(message)
    if success then refreshInventory() end
end)

CreateThread(function()
    while true do
        if isOpen then
            if IsPauseMenuActive() or IsEntityDead(PlayerPedId()) then
                closeInventory()
            else
                refreshInventory()
            end
            Wait(Config.RefreshInterval)
        else
            Wait(500)
        end
    end
end)

AddEventHandler("onResourceStop", function(resource)
    if resource == GetCurrentResourceName() then
        SetNuiFocus(false, false)
    end
end)

# Nexus Inventory

Nexus Inventory is a custom FiveM NUI for servers that use `ox_inventory`. It reads the player's real inventory, item labels, descriptions, metadata-backed item identity, slot weight, and carry weight through ox_inventory's documented client exports.

The ox_inventory framework bridge must already be configured for the server's QBCore or ESX setup. This resource does not replace ox_inventory's storage, item definitions, use callbacks, or persistence.

## Features

- Nexus HUD visual style with category filters, item search, item details, and carry-weight display.
- Item use delegates to `exports.ox_inventory:useSlot`, preserving ox_inventory's validation and item callbacks.
- Dropping one item is validated server-side against the live ox_inventory slot, removes the item through `RemoveItem`, and creates a world drop through `CustomDrop`.
- If creating the world drop fails after removal, the resource attempts to restore the item to its original slot and reports a restoration failure explicitly.
- Item category and rarity mappings are configurable in `config.lua`.
- Default open/close key is F3; the `/nexusinventory` command is also available.

## Installation

1. Copy `nexus-inventory` into the server's FiveM `resources` folder.
2. Ensure ox_inventory is configured and started for QBCore or ESX.
3. Add the resource after ox_inventory in `server.cfg`:

   ```cfg
   ensure ox_inventory
   ensure nexus-inventory
   ```

4. Start the server or run `refresh` and `ensure nexus-inventory` in the server console.
5. Open with F3 or run `/nexusinventory`. The key can be changed in FiveM's key bindings or `config.lua`.

Item pictures are loaded from ox_inventory's `web/images` folder. If an item image does not exist, the interface displays a fallback glyph.

## Schritt-für-Schritt-Tutorial

Dieses Tutorial setzt einen bereits eingerichteten FiveM-Server mit QBCore oder ESX und einem dafür konfigurierten `ox_inventory` voraus. Nexus Inventory ersetzt weder `ox_inventory` noch dessen Datenbank oder Framework-Bridge.

### 1. Ressource installieren

1. Lade `nexus-inventory-1.0.0.zip` herunter und entpacke das Archiv.
2. Kopiere den Ordner `nexus-inventory` in den `resources`-Ordner deines Servers. Zum Beispiel:

   ```text
   server-data/
   └── resources/
       ├── [ox]/
       │   └── ox_inventory/
       └── [nexus]/
           └── nexus-inventory/
               ├── fxmanifest.lua
               ├── client.lua
               ├── server.lua
               └── html/
   ```

   Wichtig: `fxmanifest.lua` muss direkt in `nexus-inventory` liegen, nicht in einem zusätzlichen verschachtelten ZIP-Ordner.

3. Öffne die `server.cfg` und starte die Ressource nach `ox_inventory`:

   ```cfg
   ensure ox_inventory
   ensure nexus-inventory
   ```

   Falls deine Ressourcen in einem anderen Ordner liegen, passe den Pfad entsprechend an, zum Beispiel `ensure [nexus]/nexus-inventory`.

### 2. Server starten und öffnen

1. Starte den Server neu. Bei einem bereits laufenden Server kannst du in der Serverkonsole `refresh` und danach `ensure nexus-inventory` ausführen.
2. Prüfe in der Serverkonsole, dass `ox_inventory` vor `nexus-inventory` gestartet ist und keine Startfehler ausgegeben werden.
3. Verbinde dich mit dem Server und öffne das Inventar mit **F3** oder über den Chatbefehl **`/nexusinventory`**.
4. Wähle einen Slot, um die Itemdetails zu sehen. **Benutzen** übergibt den Slot an `ox_inventory`; **1 ablegen** entfernt ein Item serverseitig aus genau diesem Slot und erstellt dafür einen Welt-Drop.
5. Schließe das Inventar mit **ESC** oder über die Schaltfläche oben rechts. Die Taste lässt sich zusätzlich in FiveMs Einstellungen unter den Tastenbelegungen ändern.

### 3. Kategorien und Darstellung anpassen

Öffne `config.lua`, um die Slot-Anzahl und Zuordnung deiner Items zu ändern. Trage bei `Config.ItemCategories` jeweils den internen Itemnamen aus deiner ox_inventory-Itemdefinition ein:

```lua
Config.ItemCategories = {
    water = "Verbrauch",
    sandwich = "Verbrauch",
    phone = "Ausrüstung",
    repairkit = "Ausrüstung",
    metalscrap = "Materialien",
}
```

Nicht zugeordnete Items erscheinen unter **Sonstiges**. Optionale Seltenheitsstufen kannst du in `Config.ItemRarities` als `common`, `uncommon`, `rare` oder `epic` festlegen. Änderungen an der Konfiguration werden nach einem Neustart der Ressource wirksam:

```text
restart nexus-inventory
```

### Fehlerbehebung

- **„ox_inventory ist nicht gestartet“:** Prüfe den Ressourcennamen und stelle sicher, dass `ensure ox_inventory` vor `ensure nexus-inventory` in der `server.cfg` steht.
- **Das Inventar öffnet sich nicht:** Prüfe die F8-Konsole auf NUI-Fehler, starte beide Ressourcen erneut und teste `/nexusinventory`.
- **Eine Kategorie ist leer:** Prüfe den internen Itemnamen in `Config.ItemCategories`; nicht zugeordnete Items findest du unter **Sonstiges**.
- **Ein Itembild fehlt:** Das Bild muss als `<itemname>.png` im Bilderordner von ox_inventory liegen. Ohne Bild wird ein Ersatzsymbol angezeigt.
- **ESX oder QBCore wird nicht erkannt:** Die passende ox_inventory-Framework-Bridge muss zuerst installiert und gemäß deren Anleitung eingerichtet sein.

## Configuration

- `Config.DefaultKey`: default key mapping (`F3`).
- `Config.SlotCount`: number of empty slots to display when the inventory has no item in them.
- `Config.RefreshInterval`: live inventory refresh interval in milliseconds.
- `Config.ItemCategories`: map item names to the categories shown in the UI.
- `Config.ItemRarities`: optional map of item names to `common`, `uncommon`, `rare`, or `epic`.
- `Config.DropCooldown`: server-side delay between drop requests per player.

This resource depends on ox_inventory and does not work with qb-inventory or the standalone ESX inventory. The browser page `/inventory-preview` is a visual concept preview only; in-game data and item actions come from ox_inventory.

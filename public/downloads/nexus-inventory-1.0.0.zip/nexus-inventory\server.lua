local lastDropAt = {}
local dropping = {}

local function respond(playerId, success, message)
    TriggerClientEvent("nexus-inventory:client:dropResult", playerId, success, message)
end

RegisterNetEvent("nexus-inventory:server:dropItem", function(slot)
    local playerId = source
    slot = tonumber(slot)

    local now = GetGameTimer()
    if dropping[playerId] or (lastDropAt[playerId] and now - lastDropAt[playerId] < Config.DropCooldown) then
        respond(playerId, false, "Bitte warte kurz, bevor du noch ein Item ablegst.")
        return
    end
    lastDropAt[playerId] = now

    if type(slot) ~= "number" or slot < 1 or slot % 1 ~= 0 then
        respond(playerId, false, "Ungültiger Inventar-Slot.")
        return
    end

    if GetResourceState("ox_inventory") ~= "started" then
        respond(playerId, false, "ox_inventory ist nicht gestartet.")
        return
    end

    dropping[playerId] = true

    local slotOk, item = pcall(function()
        return exports.ox_inventory:GetSlot(playerId, slot)
    end)

    if not slotOk then
        print(("[nexus-inventory] Could not inspect player %s inventory slot %s: %s"):format(playerId, slot, item))
    end

    if not slotOk or type(item) ~= "table" or not item.name then
        dropping[playerId] = nil
        respond(playerId, false, "Dieses Item ist nicht mehr in deinem Inventar.")
        return
    end

    local ped = GetPlayerPed(playerId)
    if ped == 0 then
        dropping[playerId] = nil
        respond(playerId, false, "Dein Spielerstatus konnte nicht ermittelt werden.")
        return
    end

    local removeOk, removed, removeError = pcall(function()
        return exports.ox_inventory:RemoveItem(playerId, item.name, 1, item.metadata, slot)
    end)

    if not removeOk then
        print(("[nexus-inventory] Could not remove %s from player %s slot %s: %s"):format(item.name, playerId, slot, removed))
    end

    if not removeOk or not removed then
        dropping[playerId] = nil
        respond(playerId, false, removeError or "Das Item konnte nicht aus dem Inventar entfernt werden.")
        return
    end

    local dropOk, dropId = pcall(function()
        return exports.ox_inventory:CustomDrop(
            Config.DropLabel,
            {
                {
                    name = item.name,
                    count = 1,
                    metadata = item.metadata,
                },
            },
            GetEntityCoords(ped),
            1,
            math.max(tonumber(item.weight) or 1, 1)
        )
    end)

    if not dropOk then
        print(("[nexus-inventory] Could not create a world drop for %s from player %s: %s"):format(item.name, playerId, dropId))
    end

    if not dropOk or not dropId then
        local restoreOk, restored = pcall(function()
            return exports.ox_inventory:AddItem(playerId, item.name, 1, item.metadata, slot)
        end)

        dropping[playerId] = nil
        if not restoreOk or not restored then
            print(("[nexus-inventory] CRITICAL: Could not restore %s to player %s after drop creation failed."):format(item.name, playerId))
            respond(playerId, false, "Drop fehlgeschlagen. Item-Wiederherstellung muss vom Serverteam geprüft werden.")
            return
        end

        respond(playerId, false, "Das Item konnte nicht auf dem Boden abgelegt werden.")
        return
    end

    dropping[playerId] = nil
    respond(playerId, true, ("%s auf dem Boden abgelegt."):format(item.label or item.name))
end)

AddEventHandler("playerDropped", function()
    local playerId = source
    lastDropAt[playerId] = nil
    dropping[playerId] = nil
end)

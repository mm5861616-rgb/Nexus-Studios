const root = document.getElementById("inventory");
const grid = document.getElementById("items-grid");
const details = document.getElementById("item-details");
const categoriesElement = document.getElementById("categories");
const hotbarElement = document.getElementById("hotbar-items");
const searchInput = document.getElementById("search-input");
const categoryNames = ["Alle", "Verbrauch", "Ausrüstung", "Materialien", "Sonstiges"];
const categoryIcons = ["▦", "✚", "◈", "⬡", "⋯"];
const fallbackIcons = {
  water: "◉", sandwich: "▰", bread: "▰", bandage: "▤", medikit: "✚",
  phone: "▯", radio: "▥", lockpick: "⌁", repairkit: "⚙", metalscrap: "⬡",
  copper: "〰", plastic: "⬢", iron: "⬡", steel: "⬡",
};

let inventory = { items: [], weight: 0, maxWeight: 0, slotCount: 40 };
let activeCategory = "Alle";
let selectedSlot = null;

function formatWeight(weight) {
  return `${(Number(weight || 0) / 1000).toLocaleString("de-DE", { maximumFractionDigits: 1 })} kg`;
}

function postNui(name, payload = {}) {
  return fetch(`https://${GetParentResourceName()}/${name}`, {
    method: "POST",
    headers: { "Content-Type": "application/json; charset=UTF-8" },
    body: JSON.stringify(payload),
  }).then((response) => response.json());
}

function selectedItem() {
  return inventory.items.find((item) => item.slot === selectedSlot) || null;
}

function renderCategories() {
  categoriesElement.replaceChildren();
  categoryNames.forEach((name, index) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = activeCategory === name ? "selected" : "";
    const icon = document.createElement("span");
    icon.textContent = categoryIcons[index];
    button.append(icon, document.createTextNode(name));
    if (name === "Alle") {
      const count = document.createElement("b");
      count.textContent = String(inventory.items.length);
      button.append(count);
    }
    button.addEventListener("click", () => {
      activeCategory = name;
      render();
    });
    categoriesElement.append(button);
  });
}

function makeItemImage(item) {
  const imageWrap = document.createElement("span");
  imageWrap.className = "item-image-wrap";
  const fallback = document.createElement("span");
  fallback.className = `item-glyph item-glyph-${item.name}`;
  fallback.textContent = fallbackIcons[item.name] || "◈";
  imageWrap.append(fallback);

  if (/^[a-zA-Z0-9_-]+$/.test(item.name)) {
    const image = document.createElement("img");
    image.alt = "";
    image.src = `nui://ox_inventory/web/images/${encodeURIComponent(item.name)}.png`;
    image.addEventListener("load", () => imageWrap.classList.add("has-image"), { once: true });
    image.addEventListener("error", () => image.remove(), { once: true });
    imageWrap.append(image);
  }

  return imageWrap;
}

function renderGrid() {
  const query = searchInput.value.trim().toLocaleLowerCase("de");
  const filtered = inventory.items.filter((item) =>
    (activeCategory === "Alle" || item.category === activeCategory) &&
    (!query || `${item.label} ${item.name} ${item.description} ${item.category}`.toLocaleLowerCase("de").includes(query))
  );
  const slotCount = Math.max(Number(inventory.slotCount) || 40, ...inventory.items.map((item) => item.slot || 0), 1);
  const bySlot = new Map(inventory.items.map((item) => [item.slot, item]));
  grid.replaceChildren();

  for (let slot = 1; slot <= slotCount; slot += 1) {
    const item = bySlot.get(slot);
    const button = document.createElement("button");
    button.type = "button";
    button.className = "inventory-slot";
    button.setAttribute("aria-label", item ? `${item.label}, Menge ${item.count}, ${formatWeight(item.weight * item.count)}` : `Leerer Slot ${slot}`);

    const index = document.createElement("span");
    index.className = "slot-index";
    index.textContent = String(slot).padStart(2, "0");
    button.append(index);

    if (!item || !filtered.some((entry) => entry.slot === item.slot)) {
      button.classList.add("empty-slot");
      if (item) button.classList.add("filtered-slot");
      const empty = document.createElement("span");
      empty.className = "empty-plus";
      empty.textContent = item ? "·" : "+";
      button.append(empty);
    } else {
      if (item.rarity) button.classList.add(`rarity-${item.rarity}`);
      if (selectedSlot === item.slot) button.classList.add("is-selected");
      button.append(makeItemImage(item));

      const label = document.createElement("span");
      label.className = "slot-name";
      label.textContent = item.label;
      button.append(label);

      if (item.count > 1) {
        const count = document.createElement("b");
        count.className = "slot-count";
        count.textContent = `x${item.count}`;
        button.append(count);
      }

      const weight = document.createElement("span");
      weight.className = "slot-weight";
      weight.textContent = formatWeight(item.weight * item.count);
      button.append(weight);
      button.addEventListener("click", () => {
        selectedSlot = item.slot;
        render();
      });
    }

    grid.append(button);
  }

  document.getElementById("items-count").textContent = `${filtered.length} Gegenstände`;
  document.getElementById("occupied-count").textContent = String(inventory.items.length);
}

function renderDetails() {
  const item = selectedItem();
  details.replaceChildren();

  if (!item) {
    const empty = document.createElement("div");
    empty.className = "no-selection";
    const icon = document.createElement("span");
    icon.textContent = "◈";
    const title = document.createElement("b");
    title.textContent = "Kein Item ausgewählt";
    const description = document.createElement("p");
    description.textContent = "Wähle einen Gegenstand aus deinem Inventar.";
    empty.append(icon, title, description);
    details.append(empty);
    return;
  }

  const art = document.createElement("div");
  art.className = `details-item-art rarity-${item.rarity || "common"}`;
  art.append(makeItemImage(item));
  const rarity = document.createElement("i");
  rarity.textContent = String(item.rarity || "common").toUpperCase();
  art.append(rarity);

  const eyebrow = document.createElement("span");
  eyebrow.className = "details-label";
  eyebrow.textContent = "ITEM-DETAILS";
  const title = document.createElement("h2");
  title.textContent = item.label;
  const description = document.createElement("p");
  description.textContent = item.description || item.name;

  const properties = document.createElement("div");
  properties.className = "details-properties";
  [
    ["KATEGORIE", item.category || "Sonstiges"],
    ["GEWICHT", formatWeight(item.weight)],
    ["IM BESITZ", `${item.count} Stück`],
  ].forEach(([label, value]) => {
    const row = document.createElement("span");
    const rowLabel = document.createElement("small");
    rowLabel.textContent = label;
    const rowValue = document.createElement("b");
    rowValue.textContent = value;
    row.append(rowLabel, rowValue);
    properties.append(row);
  });

  const actions = document.createElement("div");
  actions.className = "details-actions";
  const useButton = document.createElement("button");
  useButton.type = "button";
  useButton.className = "use-button";
  useButton.textContent = "Benutzen";
  useButton.addEventListener("click", async () => {
    useButton.disabled = true;
    try {
      const result = await postNui("useItem", { slot: item.slot });
      showNotice(result.error || `${item.label} wird benutzt.`);
    } catch {
      showNotice("Das Item konnte nicht benutzt werden.");
    } finally {
      useButton.disabled = false;
    }
  });
  const dropButton = document.createElement("button");
  dropButton.type = "button";
  dropButton.className = "drop-button";
  dropButton.textContent = "1 ablegen";
  dropButton.addEventListener("click", async () => {
    dropButton.disabled = true;
    try {
      const result = await postNui("dropItem", { slot: item.slot });
      if (!result.ok) showNotice(result.error || "Das Item konnte nicht abgelegt werden.");
    } catch {
      showNotice("Das Item konnte nicht abgelegt werden.");
    } finally {
      dropButton.disabled = false;
    }
  });
  actions.append(useButton, dropButton);
  details.append(art, eyebrow, title, description, properties, actions);
}

function renderHotbar() {
  hotbarElement.replaceChildren();
  for (let slot = 1; slot <= 5; slot += 1) {
    const item = inventory.items.find((entry) => entry.slot === slot);
    const button = document.createElement("button");
    button.type = "button";
    button.className = "hotbar-slot";
    button.setAttribute("aria-label", item ? `Schnellzugriff ${slot}: ${item.label}` : `Schnellzugriff ${slot} leer`);
    const key = document.createElement("kbd");
    key.textContent = String(slot);
    button.append(key);
    if (item) {
      button.append(makeItemImage(item));
      button.addEventListener("click", () => postNui("useItem", { slot: item.slot }).catch(() => showNotice("Das Item konnte nicht benutzt werden.")));
    } else {
      const empty = document.createElement("span");
      empty.textContent = "—";
      button.append(empty);
    }
    hotbarElement.append(button);
  }
}

function render() {
  const currentWeight = Number(inventory.weight) || 0;
  const maxWeight = Number(inventory.maxWeight) || 0;
  document.getElementById("current-weight").textContent = formatWeight(currentWeight);
  document.getElementById("max-weight").textContent = formatWeight(maxWeight);
  document.getElementById("weight-fill").style.width = `${maxWeight > 0 ? Math.min(100, currentWeight / maxWeight * 100) : 0}%`;
  renderCategories();
  renderGrid();
  renderDetails();
  renderHotbar();
}

let noticeTimer;
function showNotice(message) {
  const notice = document.getElementById("notice");
  notice.textContent = message || "";
  notice.classList.add("is-visible");
  clearTimeout(noticeTimer);
  noticeTimer = setTimeout(() => notice.classList.remove("is-visible"), 2200);
}

function setVisible(visible) {
  root.classList.toggle("is-open", Boolean(visible));
  root.setAttribute("aria-hidden", String(!visible));
}

document.getElementById("close-button").addEventListener("click", () => postNui("close"));
searchInput.addEventListener("input", renderGrid);
window.addEventListener("message", (event) => {
  const data = event.data;
  if (!data || typeof data !== "object") return;
  if (data.action === "open") {
    inventory = data.inventory || inventory;
    selectedSlot = inventory.items[0]?.slot ?? null;
    activeCategory = "Alle";
    searchInput.value = "";
    render();
    setVisible(true);
  } else if (data.action === "inventory") {
    inventory = data.inventory || inventory;
    if (!inventory.items.some((item) => item.slot === selectedSlot)) selectedSlot = null;
    render();
  } else if (data.action === "close") {
    setVisible(false);
  } else if (data.action === "notice") {
    showNotice(data.message);
  }
});

window.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && root.classList.contains("is-open")) {
    event.preventDefault();
    postNui("close");
  }
});

setVisible(false);

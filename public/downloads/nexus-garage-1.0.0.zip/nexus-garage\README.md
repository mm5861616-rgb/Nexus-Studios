# Nexus Garage

Nexus Garage is a FiveM vehicle garage resource for servers using QBCore or ESX. It uses the framework's existing owned-vehicle database, so it does not introduce a second vehicle registry or a separate SQL schema.

## Features

- Dark NUI garage with a server-loaded list of the player's stored vehicles.
- Park and retrieve vehicles near configured garage locations.
- Server checks framework ownership, stored/out status, player distance, vehicle network entity, license plate, and driver seat.
- The framework vehicle properties are applied when the vehicle is retrieved.
- Fuel, engine health, and body health are saved when parking.
- Concurrent garage requests are locked per player, and a plate cannot be retrieved twice while marked out.
- Garage locations, spawn points, interaction key, and distances are configurable.

## Requirements

- FiveM server with OneSync enabled.
- QBCore with the standard `player_vehicles` table, or ESX Legacy with the standard `owned_vehicles` table.
- `oxmysql` started before this resource.
- Your framework's existing vehicle ownership records must be populated and use stored state `1` / out state `0`.

No SQL migration is required. The default framework mode is `auto`; if both framework resources are started, QBCore is preferred. Set `Config.Framework` explicitly to `"qbcore"` or `"esx"` if needed.

## Install

1. Copy `nexus-garage` into the server's FiveM `resources` folder. Keep `fxmanifest.lua` at the root of the resource folder.
2. Configure `Config.Garages` in `config.lua` with a garage point and a clear vehicle spawn position suitable for your map.
3. Start dependencies and then the garage in `server.cfg`:

   ```cfg
   ensure oxmysql
   ensure qb-core
   ensure nexus-garage
   ```

   For ESX, start `es_extended` before `nexus-garage` instead of `qb-core`. Keep the resource names consistent with your server.
4. Restart the server or run `refresh` followed by `ensure nexus-garage` in its console.
5. Walk to the garage marker and press **E**, press **F6**, or use `/nexusgarage`.

The provided default location is Legion Square (`215.8, -810.1, 30.7`) and is only an example. Replace it and its spawn point for your server before use.

## Configure more locations

Each entry needs a marker coordinate and a nearby clear spawn coordinate:

```lua
Config.Garages = {
    {
        label = "Legion Square Garage",
        coords = vector3(215.8, -810.1, 30.7),
        spawn = vector4(229.7, -800.1, 30.6, 157.0),
    },
    {
        label = "Sandy Shores Garage",
        coords = vector3(1737.5, 3710.7, 34.1),
        spawn = vector4(1732.5, 3718.0, 34.2, 20.0),
    },
}
```

The spawn point is checked for another vehicle before a stored vehicle is retrieved. The player's current position and vehicle must be within `Config.GarageDistance` of a configured garage.

## Database behavior

- QBCore reads `player_vehicles` by `citizenid`; a vehicle is available to retrieve only when `state = 1`. Parking sets `state = 1`; retrieving sets it to `0`.
- ESX reads `owned_vehicles` by `owner`; a vehicle is available to retrieve only when `stored = 1`. Parking sets `stored = 1`; retrieving sets it to `0`.
- On parking, the resource persists fuel, engine, and body values. The values are supplied by the in-game client and range-clamped; they are not an anti-cheat authority. Existing vehicle properties/mods remain in the framework's record and are applied on retrieval.
- SQL parameters are bound through oxmysql. The resource does not accept a model from the browser UI; models and properties come from the player's owned vehicle database record.
- If a vehicle cannot be spawned, its stored state is restored when the server confirms the vehicle was not created.

This resource targets the standard QBCore and ESX table/column names. A customized vehicle schema requires adapting the bound queries in `server.lua`.

## Troubleshooting

- **Framework not detected:** confirm `qb-core` or `es_extended` is running first. Set `Config.Framework` explicitly if the server runs both.
- **Garage list is empty:** confirm the player owns a vehicle in the framework's vehicle table and its stored state is `1`.
- **Vehicles cannot be parked:** the database record must belong to the current player, the player must be the driver, and the car must be near a configured garage.
- **Retrieval is blocked:** move vehicles away from the configured spawn point and verify the coordinates/heading.
- **Database errors:** check oxmysql is running before this resource and inspect the server console for the query error.

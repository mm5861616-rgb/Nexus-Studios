const garage = document.getElementById("garage");
const vehicleList = document.getElementById("vehicles");
const statusText = document.getElementById("status");
const vehicleCount = document.getElementById("vehicle-count");

function post(name, data = {}) {
  return fetch(`https://${GetParentResourceName()}/${name}`, {
    method: "POST",
    headers: { "Content-Type": "application/json; charset=UTF-8" },
    body: JSON.stringify(data),
  }).then((response) => response.json());
}

function closeGarage() {
  garage.classList.remove("is-open");
  post("close");
}

function displayName(vehicle) {
  if (typeof vehicle.label === "string" && vehicle.label.length > 0) return vehicle.label;
  const model = vehicle.properties?.model;
  if (typeof model !== "string") return "Fahrzeug";
  const label = model.replace(/_/g, " ");
  return label.charAt(0).toUpperCase() + label.slice(1);
}

function renderVehicles(vehicles = []) {
  vehicleList.replaceChildren();
  vehicleCount.textContent = `${vehicles.length} ${vehicles.length === 1 ? "FAHRZEUG" : "FAHRZEUGE"}`;
  if (vehicles.length === 0) {
    const empty = document.createElement("div");
    empty.className = "empty";
    const title = document.createElement("b");
    title.textContent = "Keine eingeparkten Fahrzeuge";
    const hint = document.createElement("span");
    hint.textContent = "Fahrzeuge erscheinen hier, sobald sie in einer Garage eingeparkt wurden.";
    empty.append(title, hint);
    vehicleList.append(empty);
    return;
  }

  vehicles.forEach((vehicle) => {
    const card = document.createElement("article");
    card.className = "vehicle-card";
    const symbol = document.createElement("span");
    symbol.className = "vehicle-symbol";
    symbol.textContent = "▱";
    const info = document.createElement("div");
    info.className = "vehicle-info";
    const title = document.createElement("strong");
    title.textContent = displayName(vehicle);
    const plate = document.createElement("span");
    plate.textContent = `KENNZEICHEN · ${vehicle.plate}`;
    info.append(title, plate);
    const button = document.createElement("button");
    button.className = "spawn-button";
    button.type = "button";
    button.textContent = "Ausparken";
    button.addEventListener("click", async () => {
      button.disabled = true;
      button.textContent = "Lädt...";
      const result = await post("spawn", { plate: vehicle.plate });
      if (!result.ok) {
        statusText.textContent = result.error || "Fahrzeug konnte nicht ausgeparkt werden.";
        button.disabled = false;
        button.textContent = "Ausparken";
        return;
      }
      statusText.textContent = "Fahrzeug wird bereitgestellt...";
    });
    card.append(symbol, info, button);
    vehicleList.append(card);
  });
}

window.addEventListener("message", (event) => {
  const message = event.data;
  if (message.action === "open") {
    garage.classList.add("is-open");
    statusText.textContent = "Fahrzeugdaten werden sicher vom Server geladen.";
    document.querySelector(".garage-badge").lastChild.textContent = ` ${message.garage || "GARAGE"}`;
    renderVehicles(message.vehicles);
  } else if (message.action === "vehicles") {
    renderVehicles(message.vehicles);
    statusText.textContent = "Fahrzeugliste aktualisiert.";
  } else if (message.action === "notice") {
    statusText.textContent = message.message;
  } else if (message.action === "close") {
    garage.classList.remove("is-open");
  }
});

document.getElementById("close").addEventListener("click", closeGarage);
document.getElementById("refresh").addEventListener("click", async () => {
  statusText.textContent = "Fahrzeuge werden aktualisiert...";
  const result = await post("refresh");
  if (!result.ok) statusText.textContent = result.error || "Fahrzeuge konnten nicht geladen werden.";
});
document.getElementById("store").addEventListener("click", async () => {
  statusText.textContent = "Fahrzeug wird sicher eingeparkt...";
  const result = await post("store");
  statusText.textContent = result.message || result.error || "Einparken fehlgeschlagen.";
  if (result.ok) {
    const refreshed = await post("refresh");
    if (!refreshed.ok) statusText.textContent = refreshed.error || "Fahrzeug geparkt; Liste konnte nicht aktualisiert werden.";
  }
});
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") closeGarage();
});

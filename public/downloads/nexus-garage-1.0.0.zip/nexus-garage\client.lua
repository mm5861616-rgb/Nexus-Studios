local isOpen = false
local requestCounter = 0
local pendingRequests = {}

local function notify(message)
    BeginTextCommandThefeedPost("STRING")
    AddTextComponentSubstringPlayerName(tostring(message))
    EndTextCommandThefeedPostTicker(false, true)
    SendNUIMessage({ action = "notice", message = message })
end

local function serverRequest(action, data)
    requestCounter = requestCounter + 1
    local requestId = requestCounter
    local responsePromise = promise.new()
    pendingRequests[requestId] = responsePromise

    TriggerServerEvent("nexus-garage:server:request", requestId, {
        action = action,
        plate = data and data.plate,
        netId = data and data.netId,
        fuel = data and data.fuel,
        engine = data and data.engine,
        body = data and data.body,
    })

    SetTimeout(10000, function()
        if pendingRequests[requestId] then
            pendingRequests[requestId] = nil
            responsePromise:resolve({ ok = false, error = "Der Garagenserver antwortet nicht. Bitte erneut versuchen." })
        end
    end)

    return Citizen.Await(responsePromise)
end

RegisterNetEvent("nexus-garage:client:response", function(requestId, result)
    local responsePromise = pendingRequests[requestId]
    if responsePromise then
        pendingRequests[requestId] = nil
        responsePromise:resolve(result)
    end
end)

RegisterNetEvent("nexus-garage:client:notice", function(message)
    notify(message)
end)

local function closeGarage()
    if not isOpen then
        return
    end
    isOpen = false
    SetNuiFocus(false, false)
    SendNUIMessage({ action = "close" })
end

local function openGarage()
    if isOpen then
        closeGarage()
        return
    end

    local result = serverRequest("list")
    if not result.ok then
        notify(result.error or "Garage konnte nicht geöffnet werden.")
        return
    end

    isOpen = true
    SetNuiFocus(true, true)
    for _, vehicle in ipairs(result.vehicles) do
        local model = vehicle.properties.model
        if type(model) == "string" then
            model = joaat(model)
        end
        if type(model) == "number" then
            local displayName = GetDisplayNameFromVehicleModel(model)
            if displayName and displayName ~= "CARNOTFOUND" then
                local label = GetLabelText(displayName)
                vehicle.label = label ~= "" and label ~= "NULL" and label or displayName
            end
        end
    end
    SendNUIMessage({
        action = "open",
        vehicles = result.vehicles,
        garage = result.garage,
    })
end

local function applyVehicleProperties(vehicle, properties)
    if type(properties) ~= "table" then
        return false
    end

    if GetResourceState("qb-core") == "started" then
        local success = pcall(function()
            exports["qb-core"]:GetCoreObject().Functions.SetVehicleProperties(vehicle, properties)
        end)
        if success then
            return true
        end
    end
    if GetResourceState("es_extended") == "started" then
        local success = pcall(function()
            exports["es_extended"]:getSharedObject().Game.SetVehicleProperties(vehicle, properties)
        end)
        if success then
            return true
        end
    end
    return true
end

local function spawnVehicle(vehicleData)
    local properties = vehicleData.properties
    if type(properties) ~= "table" or not properties.model then
        return false, "Die gespeicherten Fahrzeugdaten sind ungültig."
    end

    local model = properties.model
    if type(model) == "string" then
        model = joaat(model)
    end
    if not IsModelInCdimage(model) or not IsModelAVehicle(model) then
        return false, "Das gespeicherte Fahrzeugmodell ist ungültig."
    end

    RequestModel(model)
    local timeoutAt = GetGameTimer() + 10000
    while not HasModelLoaded(model) and GetGameTimer() < timeoutAt do
        Wait(50)
    end
    if not HasModelLoaded(model) then
        return false, "Fahrzeugmodell konnte nicht geladen werden."
    end

    local spawn = vehicleData.spawn
    local vehicle = CreateVehicle(model, spawn.x, spawn.y, spawn.z, spawn.heading, true, true)
    SetModelAsNoLongerNeeded(model)
    if vehicle == 0 or not DoesEntityExist(vehicle) then
        return false, "Fahrzeug konnte nicht erstellt werden."
    end

    SetVehicleNumberPlateText(vehicle, vehicleData.plate)
    applyVehicleProperties(vehicle, properties)
    SetVehicleOnGroundProperly(vehicle)
    SetEntityAsMissionEntity(vehicle, true, true)
    SetPedIntoVehicle(PlayerPedId(), vehicle, -1)
    return true
end

RegisterCommand(Config.Command, openGarage, false)
RegisterKeyMapping(Config.Command, "Nexus Garage öffnen", "keyboard", Config.DefaultKey)

RegisterNUICallback("close", function(_, callback)
    closeGarage()
    callback({ ok = true })
end)

RegisterNUICallback("refresh", function(_, callback)
    local result = serverRequest("list")
    if result.ok then
        SendNUIMessage({ action = "vehicles", vehicles = result.vehicles })
    end
    callback(result)
end)

RegisterNUICallback("spawn", function(data, callback)
    local plate = type(data) == "table" and data.plate
    local result = serverRequest("spawn", { plate = plate })
    if not result.ok then
        callback(result)
        return
    end

    local spawned, spawnError = spawnVehicle(result.vehicle)
    if not spawned then
        serverRequest("spawnFailed", { plate = plate })
        callback({ ok = false, error = spawnError })
        return
    end

    Wait(250)
    serverRequest("spawnComplete", {
        plate = plate,
        netId = NetworkGetNetworkIdFromEntity(GetVehiclePedIsIn(PlayerPedId(), false)),
    })
    closeGarage()
    callback({ ok = true })
end)

RegisterNUICallback("store", function(_, callback)
    local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)
    if vehicle == 0 or GetPedInVehicleSeat(vehicle, -1) ~= PlayerPedId() then
        callback({ ok = false, error = "Setze dich zum Einparken auf den Fahrersitz." })
        return
    end

    local networkId = NetworkGetNetworkIdFromEntity(vehicle)
    local result = serverRequest("store", {
        netId = networkId,
        fuel = GetVehicleFuelLevel(vehicle),
        engine = GetVehicleEngineHealth(vehicle),
        body = GetVehicleBodyHealth(vehicle),
    })
    if result.ok then
        closeGarage()
    end
    callback(result)
end)

CreateThread(function()
    while true do
        local waitTime = 1000
        local playerCoords = GetEntityCoords(PlayerPedId())
        for _, garage in ipairs(Config.Garages) do
            local distance = #(playerCoords - garage.coords)
            if distance < 20.0 then
                waitTime = 0
                DrawMarker(
                    Config.Marker.type,
                    garage.coords.x,
                    garage.coords.y,
                    garage.coords.z + 0.15,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    Config.Marker.scale.x,
                    Config.Marker.scale.y,
                    Config.Marker.scale.z,
                    Config.Marker.color.r,
                    Config.Marker.color.g,
                    Config.Marker.color.b,
                    Config.Marker.color.a,
                    false,
                    true,
                    2,
                    false,
                    nil,
                    nil,
                    false
                )
                if distance <= Config.InteractDistance then
                    BeginTextCommandDisplayHelp("STRING")
                    AddTextComponentSubstringPlayerName("Drücke ~INPUT_CONTEXT~, um die Nexus Garage zu öffnen")
                    EndTextCommandDisplayHelp(0, false, true, -1)
                    if IsControlJustReleased(0, 38) then
                        openGarage()
                    end
                end
            end
        end
        Wait(waitTime)
    end
end)

AddEventHandler("onResourceStop", function(resource)
    if resource == GetCurrentResourceName() then
        SetNuiFocus(false, false)
    end
end)

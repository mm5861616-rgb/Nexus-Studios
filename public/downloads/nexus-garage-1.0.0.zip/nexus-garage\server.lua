local QBCore
local ESX
local framework
local lastRequestAt = {}
local requestLocks = {}
local pendingSpawns = {}

local function normalizePlate(value)
    if type(value) ~= "string" then
        return nil
    end
    return string.upper((string.gsub(value, "%s+", "")))
end

local function notify(playerId, message)
    TriggerClientEvent("nexus-garage:client:notice", playerId, message)
end

local function respond(playerId, requestId, result)
    TriggerClientEvent("nexus-garage:client:response", playerId, requestId, result)
end

local function getPlayerOwner(playerId)
    if framework == "qbcore" then
        local player = QBCore.Functions.GetPlayer(playerId)
        if not player or not player.PlayerData or type(player.PlayerData.citizenid) ~= "string" then
            return nil
        end
        return player.PlayerData.citizenid
    end

    local player = ESX.GetPlayerFromId(playerId)
    if not player or type(player.identifier) ~= "string" then
        return nil
    end
    return player.identifier
end

local function getNearbyGarage(playerId)
    local ped = GetPlayerPed(playerId)
    if ped == 0 then
        return nil
    end

    local playerCoords = GetEntityCoords(ped)
    for index, garage in ipairs(Config.Garages) do
        if #(playerCoords - garage.coords) <= Config.GarageDistance then
            return garage, index
        end
    end
    return nil
end

local function getNearestVehicle(coords, radius)
    for _, vehicle in ipairs(GetAllVehicles()) do
        if DoesEntityExist(vehicle) and #(GetEntityCoords(vehicle) - coords) <= radius then
            return vehicle
        end
    end
    return 0
end

local function getVehicleRows(owner)
    if framework == "qbcore" then
        return MySQL.query.await(
            "SELECT plate, vehicle, mods, state, fuel, engine, body FROM player_vehicles WHERE citizenid = ? AND state = 1",
            { owner }
        )
    end

    return MySQL.query.await(
        "SELECT plate, vehicle, stored FROM owned_vehicles WHERE owner = ? AND stored = 1",
        { owner }
    )
end

local function parseVehicleRow(row)
    local vehicleProperties
    if framework == "qbcore" then
        local mods = type(row.mods) == "table" and row.mods or json.decode(row.mods or "{}")
        vehicleProperties = {
            model = type(mods) == "table" and mods.model or joaat(row.vehicle),
            mods = mods,
            fuelLevel = tonumber(row.fuel) or 100.0,
            engineHealth = tonumber(row.engine) or 1000.0,
            bodyHealth = tonumber(row.body) or 1000.0,
            plate = row.plate,
        }
    else
        vehicleProperties = type(row.vehicle) == "table" and row.vehicle or json.decode(row.vehicle or "{}")
    end

    if type(vehicleProperties) ~= "table" or not vehicleProperties.model then
        return nil
    end

    return {
        plate = tostring(row.plate),
        properties = vehicleProperties,
    }
end

local function listVehicles(playerId)
    local owner = getPlayerOwner(playerId)
    if not owner then
        return nil, "Deine Spielerdaten sind noch nicht geladen."
    end

    local rows = getVehicleRows(owner)
    local vehicles = {}
    for _, row in ipairs(rows) do
        local vehicle = parseVehicleRow(row)
        if vehicle then
            vehicles[#vehicles + 1] = vehicle
        else
            print(("[nexus-garage] Skipped invalid stored vehicle record for player %s, plate %s."):format(playerId, tostring(row.plate)))
        end
    end
    return vehicles
end

local function findOwnedVehicle(owner, plate)
    if framework == "qbcore" then
        return MySQL.single.await(
            "SELECT plate, vehicle, mods, state, fuel, engine, body FROM player_vehicles WHERE citizenid = ? AND REPLACE(UPPER(plate), ' ', '') = ? LIMIT 1",
            { owner, plate }
        )
    end

    return MySQL.single.await(
        "SELECT plate, vehicle, stored FROM owned_vehicles WHERE owner = ? AND REPLACE(UPPER(plate), ' ', '') = ? LIMIT 1",
        { owner, plate }
    )
end

local function setVehicleState(owner, plate, state, details)
    if framework == "qbcore" then
        if state == 1 then
            return MySQL.update.await(
                "UPDATE player_vehicles SET state = 1, fuel = ?, engine = ?, body = ? WHERE citizenid = ? AND REPLACE(UPPER(plate), ' ', '') = ? AND state = 0",
                { details.fuel, details.engine, details.body, owner, plate }
            )
        end
        return MySQL.update.await(
            "UPDATE player_vehicles SET state = 0 WHERE citizenid = ? AND REPLACE(UPPER(plate), ' ', '') = ? AND state = 1",
            { owner, plate }
        )
    end

    local function restoreVehicleState(owner, plate)
        if framework == "qbcore" then
            return MySQL.update.await(
                "UPDATE player_vehicles SET state = 1 WHERE citizenid = ? AND REPLACE(UPPER(plate), ' ', '') = ? AND state = 0",
                { owner, plate }
            )
        end
        return MySQL.update.await(
            "UPDATE owned_vehicles SET stored = 1 WHERE owner = ? AND REPLACE(UPPER(plate), ' ', '') = ? AND stored = 0",
            { owner, plate }
        )
    end

    if state == 1 then
        local row = findOwnedVehicle(owner, plate)
        if not row then
            return 0
        end
        local properties = type(row.vehicle) == "table" and row.vehicle or json.decode(row.vehicle or "{}")
        if type(properties) ~= "table" then
            return 0
        end
        properties.fuelLevel = details.fuel
        properties.engineHealth = details.engine
        properties.bodyHealth = details.body
        return MySQL.update.await(
            "UPDATE owned_vehicles SET vehicle = ?, stored = 1 WHERE owner = ? AND REPLACE(UPPER(plate), ' ', '') = ? AND stored = 0",
            { json.encode(properties), owner, plate }
        )
    end

    return MySQL.update.await(
        "UPDATE owned_vehicles SET stored = 0 WHERE owner = ? AND REPLACE(UPPER(plate), ' ', '') = ? AND stored = 1",
        { owner, plate }
    )
end

local function handleRequest(playerId, request)
    if type(request) ~= "table" or type(request.action) ~= "string" then
        return { ok = false, error = "Ungültige Garagenanfrage." }
    end

    if not getNearbyGarage(playerId) then
        return { ok = false, error = "Du bist zu weit von einer Garage entfernt." }
    end

    local owner = getPlayerOwner(playerId)
    if not owner then
        return { ok = false, error = "Deine Spielerdaten sind noch nicht geladen." }
    end

    if request.action == "list" then
        local vehicles = listVehicles(playerId)
        if not vehicles then
            return { ok = false, error = "Deine Fahrzeuge konnten nicht geladen werden." }
        end
        local garage = getNearbyGarage(playerId)
        return { ok = true, vehicles = vehicles, garage = garage.label }
    end

    if request.action == "spawn" then
        local plate = normalizePlate(request.plate)
        if not plate or #plate < 1 or #plate > 12 then
            return { ok = false, error = "Ungültiges Kennzeichen." }
        end

        local row = findOwnedVehicle(owner, plate)
        if not row then
            return { ok = false, error = "Dieses Fahrzeug gehört nicht dir." }
        end
        local stored = framework == "qbcore" and tonumber(row.state) == 1 or framework == "esx" and tonumber(row.stored) == 1
        if not stored then
            return { ok = false, error = "Dieses Fahrzeug ist bereits ausgeparkt." }
        end

        local _, garageIndex = getNearbyGarage(playerId)
        local spawn = Config.Garages[garageIndex].spawn
        if getNearestVehicle(vector3(spawn.x, spawn.y, spawn.z), Config.SpawnClearance) ~= 0 then
            return { ok = false, error = "Der Ausparkplatz ist blockiert." }
        end

        local updated = setVehicleState(owner, plate, 0)
        if updated ~= 1 then
            return { ok = false, error = "Der Fahrzeugstatus hat sich geändert. Lade die Liste neu." }
        end
        local vehicle = parseVehicleRow(row)
        if not vehicle then
            restoreVehicleState(owner, plate)
            return { ok = false, error = "Die gespeicherten Fahrzeugdaten sind ungültig." }
        end
        vehicle.spawn = {
            x = spawn.x,
            y = spawn.y,
            z = spawn.z,
            heading = spawn.w,
        }
        pendingSpawns[playerId] = {
            plate = plate,
            position = vector3(spawn.x, spawn.y, spawn.z),
            expiresAt = GetGameTimer() + 15000,
        }
        return { ok = true, vehicle = vehicle }
    end

    if request.action == "spawnFailed" then
        local plate = normalizePlate(request.plate)
        local pending = pendingSpawns[playerId]
        if not plate or not pending or pending.plate ~= plate or GetGameTimer() > pending.expiresAt then
            return { ok = false, error = "Ungültiges Kennzeichen." }
        end
        local spawnedVehicle = getNearestVehicle(pending.position, Config.SpawnClearance + 2.0)
        if spawnedVehicle ~= 0 and normalizePlate(GetVehicleNumberPlateText(spawnedVehicle)) == plate then
            return { ok = false, error = "Das Fahrzeug wurde bereits ausgeparkt." }
        end
        local updated = restoreVehicleState(owner, plate)
        pendingSpawns[playerId] = nil
        return { ok = updated == 1, error = "Fahrzeug konnte nicht erstellt werden." }
    end

    if request.action == "spawnComplete" then
        local plate = normalizePlate(request.plate)
        local netId = tonumber(request.netId)
        local pending = pendingSpawns[playerId]
        if not plate or not netId or not pending or pending.plate ~= plate or GetGameTimer() > pending.expiresAt then
            return { ok = false, error = "Ausparkvorgang konnte nicht bestätigt werden." }
        end
        local spawnedVehicle = NetworkGetEntityFromNetworkId(netId)
        if spawnedVehicle == 0 or not DoesEntityExist(spawnedVehicle)
            or normalizePlate(GetVehicleNumberPlateText(spawnedVehicle)) ~= plate
            or #(GetEntityCoords(spawnedVehicle) - pending.position) > Config.SpawnClearance + 5.0 then
            return { ok = false, error = "Das gespawnte Fahrzeug konnte nicht bestätigt werden." }
        end
        pendingSpawns[playerId] = nil
        return { ok = true }
    end

    if request.action == "store" then
        local netId = tonumber(request.netId)
        if not netId or netId < 1 or netId % 1 ~= 0 then
            return { ok = false, error = "Ungültiges Fahrzeug." }
        end
        local vehicleEntity = NetworkGetEntityFromNetworkId(netId)
        if vehicleEntity == 0 or not DoesEntityExist(vehicleEntity) or GetEntityType(vehicleEntity) ~= 2 then
            return { ok = false, error = "Das Fahrzeug ist nicht mehr verfügbar." }
        end

        local playerPed = GetPlayerPed(playerId)
        if playerPed == 0 or GetPedInVehicleSeat(vehicleEntity, -1) ~= playerPed then
            return { ok = false, error = "Du musst selbst am Steuer des Fahrzeugs sitzen." }
        end

        local garage = getNearbyGarage(playerId)
        if not garage or #(GetEntityCoords(vehicleEntity) - garage.coords) > Config.GarageDistance then
            return { ok = false, error = "Stelle das Fahrzeug näher an der Garage ab." }
        end

        local plate = normalizePlate(GetVehicleNumberPlateText(vehicleEntity))
        local row = plate and findOwnedVehicle(owner, plate)
        if not row then
            return { ok = false, error = "Dieses Fahrzeug ist nicht in deinem Besitz." }
        end

        local isOut = framework == "qbcore" and tonumber(row.state) == 0 or framework == "esx" and tonumber(row.stored) == 0
        if not isOut then
            return { ok = false, error = "Dieses Fahrzeug ist bereits als eingeparkt registriert." }
        end

        local details = {
            fuel = math.max(0.0, math.min(100.0, tonumber(request.fuel) or 0.0)),
            engine = math.max(0.0, math.min(1000.0, tonumber(request.engine) or 0.0)),
            body = math.max(0.0, math.min(1000.0, tonumber(request.body) or 0.0)),
        }
        local updated = setVehicleState(owner, plate, 1, details)
        if updated ~= 1 then
            return { ok = false, error = "Fahrzeugstatus konnte nicht gespeichert werden." }
        end

        DeleteEntity(vehicleEntity)
        return { ok = true, message = "Fahrzeug sicher in der Garage geparkt." }
    end

    return { ok = false, error = "Unbekannte Garagenaktion." }
end

RegisterNetEvent("nexus-garage:server:request", function(requestId, request)
    local playerId = source
    if type(requestId) ~= "number" or requestId < 1 or requestId % 1 ~= 0 then
        return
    end
    if requestLocks[playerId] then
        respond(playerId, requestId, { ok = false, error = "Bitte warte, bis die letzte Garagenaktion abgeschlossen ist." })
        return
    end

    local action = type(request) == "table" and request.action
    local acknowledgement = action == "spawnComplete" or action == "spawnFailed"
    if not acknowledgement then
        local now = GetGameTimer()
        if lastRequestAt[playerId] and now - lastRequestAt[playerId] < Config.RequestCooldown then
            respond(playerId, requestId, { ok = false, error = "Bitte warte kurz, bevor du es erneut versuchst." })
            return
        end
        lastRequestAt[playerId] = now
    end
    requestLocks[playerId] = true

    local success, result = pcall(handleRequest, playerId, request)
    requestLocks[playerId] = nil
    if not success then
        print(("[nexus-garage] Request from player %s failed: %s"):format(playerId, tostring(result)))
        respond(playerId, requestId, { ok = false, error = "Garagenaktion fehlgeschlagen. Serverprotokoll prüfen." })
        return
    end
    respond(playerId, requestId, result)
end)

AddEventHandler("playerDropped", function()
    local playerId = source
    lastRequestAt[playerId] = nil
    requestLocks[playerId] = nil
    pendingSpawns[playerId] = nil
end)

CreateThread(function()
    while not framework do
        if Config.Framework == "auto" or Config.Framework == "qbcore" then
            if GetResourceState("qb-core") == "started" then
                local success, core = pcall(function()
                    return exports["qb-core"]:GetCoreObject()
                end)
                if success and core then
                    QBCore = core
                    framework = "qbcore"
                end
            end
        end
        if not framework and (Config.Framework == "auto" or Config.Framework == "esx") then
            if GetResourceState("es_extended") == "started" then
                local success, shared = pcall(function()
                    return exports["es_extended"]:getSharedObject()
                end)
                if success and shared then
                    ESX = shared
                    framework = "esx"
                end
            end
        end
        if not framework then
            Wait(1000)
        end
    end

    print(("[nexus-garage] Ready with %s and oxmysql."):format(framework))
end)

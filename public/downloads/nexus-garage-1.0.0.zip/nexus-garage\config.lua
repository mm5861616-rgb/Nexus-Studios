Config = {}

Config.Framework = "auto" -- "auto", "qbcore", or "esx"
Config.Command = "nexusgarage"
Config.DefaultKey = "F6"
Config.InteractDistance = 2.0
Config.GarageDistance = 25.0
Config.SpawnClearance = 3.0
Config.RequestCooldown = 1000

Config.Garages = {
    {
        label = "Legion Square Garage",
        coords = vector3(215.8, -810.1, 30.7),
        spawn = vector4(229.7, -800.1, 30.6, 157.0),
    },
}

Config.Marker = {
    type = 36,
    scale = vector3(0.8, 0.8, 0.8),
    color = { r = 67, g = 155, b = 255, a = 180 },
}

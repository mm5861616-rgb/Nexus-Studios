local framework = "standalone"
local frameworkObject
local hudEnabled = true
local playerData = {}
local needs = {
    hunger = nil,
    thirst = nil,
}

local function normalizeStatus(value)
    value = tonumber(value)
    if not value then
        return nil
    end

    if value > 100 then
        value = value / 10000
    end

    return math.floor(math.max(0, math.min(100, value)) + 0.5)
end

local function setEsxStatus(statuses)
    if type(statuses) ~= "table" then
        return
    end

    for _, status in pairs(statuses) do
        if type(status) == "table" and status.name then
            local value = status.val or status.value
            if not value and type(status.percent) == "number" then
                value = status.percent
            end

            if status.name == "hunger" then
                needs.hunger = normalizeStatus(value)
            elseif status.name == "thirst" then
                needs.thirst = normalizeStatus(value)
            end
        end
    end
end

local function loadFramework()
    local requested = string.lower(Config.Framework or "auto")
    if requested ~= "auto" and requested ~= "qb" and requested ~= "esx" then
        print(("[nexus-hud] Invalid Config.Framework '%s'; using automatic detection."):format(requested))
        requested = "auto"
    end

    if requested == "auto" or requested == "qb" then
        if GetResourceState("qb-core") == "started" then
            local success, object = pcall(function()
                return exports["qb-core"]:GetCoreObject()
            end)
            if success and object then
                framework = "qb"
                frameworkObject = object
                playerData = object.Functions.GetPlayerData() or {}
                return
            end
            print(("[nexus-hud] Could not connect to qb-core: %s"):format(object or "unknown export error"))
            if requested == "qb" then
                return
            end
        elseif requested == "qb" then
            print("[nexus-hud] Config.Framework is 'qb', but qb-core is not started.")
            return
        end
    end

    if requested == "auto" or requested == "esx" then
        if GetResourceState("es_extended") == "started" then
            local success, object = pcall(function()
                return exports["es_extended"]:getSharedObject()
            end)
            if success and object then
                framework = "esx"
                frameworkObject = object
                playerData = object.GetPlayerData() or {}
                return
            end
            print(("[nexus-hud] Could not connect to es_extended: %s"):format(object or "unknown export error"))
            if requested == "esx" then
                return
            end
        elseif requested == "esx" then
            print("[nexus-hud] Config.Framework is 'esx', but es_extended is not started.")
            return
        end
    end

    print("[nexus-hud] No supported framework detected; player needs are hidden.")
end

local function refreshEsxNeeds()
    if framework ~= "esx" or GetResourceState("esx_status") ~= "started" then
        return
    end

    for _, name in ipairs({ "hunger", "thirst" }) do
        TriggerEvent("esx_status:getStatus", name, function(status)
            if type(status) == "table" then
                local value = status.val or status.value
                if not value and type(status.percent) == "number" then
                    value = status.percent
                end
                needs[name] = normalizeStatus(value)
            end
        end)
    end
end

local function getPlayerNeeds()
    if framework == "qb" then
        local metadata = playerData.metadata or {}
        return normalizeStatus(metadata.hunger), normalizeStatus(metadata.thirst)
    end

    if framework == "esx" then
        return needs.hunger, needs.thirst
    end

    return nil, nil
end

local function getPlayerName()
    if not Config.ShowPlayerInfo then
        return nil
    end

    if frameworkObject and framework == "qb" then
        local info = playerData.charinfo or {}
        local name = table.concat({ info.firstname or "", info.lastname or "" }, " "):gsub("^%s*(.-)%s*$", "%1")
        if name ~= "" then
            return name
        end
    elseif frameworkObject and framework == "esx" then
        local name = playerData.name
        if type(name) == "string" and name ~= "" then
            return name
        end
    end

    return GetPlayerName(PlayerId())
end

local function getHeading(heading)
    local directions = { "N", "NO", "O", "SO", "S", "SW", "W", "NW" }
    local index = math.floor((heading + 22.5) / 45) % #directions + 1
    return directions[index]
end

local function getStreet(ped)
    local coords = GetEntityCoords(ped)
    local streetHash = GetStreetNameAtCoord(coords.x, coords.y, coords.z)
    local street = GetStreetNameFromHashKey(streetHash)
    return street or ""
end

local function sendHudState()
    local ped = PlayerPedId()
    if not DoesEntityExist(ped) then
        return
    end

    local health = math.max(0, math.min(100, math.floor(((GetEntityHealth(ped) - 100) / 100) * 100 + 0.5)))
    local vehicle = GetVehiclePedIsIn(ped, false)
    local inVehicle = vehicle ~= 0 and GetPedInVehicleSeat(vehicle, -1) == ped
    local hunger, thirst = getPlayerNeeds()
    local hour = GetClockHours()
    local minute = GetClockMinutes()
    local heading = GetEntityHeading(ped)
    local isDead = IsEntityDead(ped)

    SendNUIMessage({
        action = "update",
        visible = hudEnabled
            and not (Config.HideOnPauseMenu and IsPauseMenuActive())
            and not (Config.HideWhenDead and isDead),
        showPlayerInfo = Config.ShowPlayerInfo,
        playerName = getPlayerName(),
        playerId = GetPlayerServerId(PlayerId()),
        health = health,
        armor = math.max(0, math.min(100, GetPedArmour(ped))),
        hunger = hunger,
        thirst = thirst,
        stamina = math.floor(GetPlayerSprintStaminaRemaining(PlayerId()) + 0.5),
        talking = NetworkIsPlayerTalking(PlayerId()),
        street = getStreet(ped),
        direction = getHeading(heading),
        time = ("%02d:%02d"):format(hour, minute),
        date = ("%02d.%02d.%04d"):format(GetClockDayOfMonth(), GetClockMonth() + 1, GetClockYear()),
        isVehicle = inVehicle,
        speed = inVehicle and math.floor(GetEntitySpeed(vehicle) * 3.6 + 0.5) or 0,
        fuel = inVehicle and math.floor(math.max(0, math.min(100, GetVehicleFuelLevel(vehicle))) + 0.5) or 0,
        engine = inVehicle and math.floor(math.max(0, math.min(100, GetVehicleEngineHealth(vehicle) / 10)) + 0.5) or 0,
        gear = inVehicle and GetVehicleCurrentGear(vehicle) or 0,
    })
end

RegisterCommand(Config.Command, function()
    hudEnabled = not hudEnabled
    SendNUIMessage({ action = "visibility", visible = hudEnabled })
end, false)

RegisterKeyMapping(Config.Command, "Nexus HUD ein- oder ausblenden", "keyboard", Config.DefaultKey)

AddEventHandler("onClientResourceStart", function(resourceName)
    if resourceName ~= GetCurrentResourceName() then
        return
    end
    loadFramework()
    refreshEsxNeeds()
end)

RegisterNetEvent("QBCore:Client:OnPlayerLoaded", function()
    if frameworkObject and framework == "qb" then
        playerData = frameworkObject.Functions.GetPlayerData() or {}
    end
end)

RegisterNetEvent("QBCore:Player:SetPlayerData", function(data)
    if framework == "qb" and type(data) == "table" then
        playerData = data
    end
end)

RegisterNetEvent("esx:playerLoaded", function(data)
    if framework == "esx" and type(data) == "table" then
        playerData = data
        refreshEsxNeeds()
    end
end)

RegisterNetEvent("esx:setPlayerData", function(key, value)
    if framework == "esx" and type(key) == "string" then
        playerData[key] = value
    end
end)

RegisterNetEvent("esx_status:onTick", function(statuses)
    if framework == "esx" then
        setEsxStatus(statuses)
    end
end)

CreateThread(function()
    while true do
        if framework == "esx" then
            refreshEsxNeeds()
        end
        Wait(Config.StatusRefreshInterval)
    end
end)

CreateThread(function()
    while true do
        sendHudState()
        Wait(Config.UpdateInterval)
    end
end)

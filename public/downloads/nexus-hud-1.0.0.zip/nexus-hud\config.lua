Config = {}

Config.Framework = "auto" -- "auto", "qb", or "esx"
Config.Command = "hud"
Config.DefaultKey = "F10"
Config.UpdateInterval = 250
Config.StatusRefreshInterval = 2500
Config.HideOnPauseMenu = true
Config.HideWhenDead = true
Config.ShowPlayerInfo = true

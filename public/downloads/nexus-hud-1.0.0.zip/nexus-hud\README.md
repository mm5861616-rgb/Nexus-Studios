# Nexus HUD

Kostenloses FiveM-HUD für QBCore und ESX. Das HUD aktualisiert Spielwerte nativ in FiveM und zeigt sie über NUI an; Hunger und Durst werden nur eingeblendet, wenn ein unterstütztes Framework die Werte liefert.

## Funktionen

- Automatische Erkennung von `qb-core` und `es_extended` (oder per Config festlegen).
- Gesundheit, Rüstung, Hunger, Durst, Ausdauer und Mikrofonstatus.
- Runde Statusanzeigen neben der FiveM-Minimap; der Mikrofonstatus verwendet ein Mikrofonsymbol.
- Geschwindigkeitsanzeige in km/h, Gang, Tank und Motorzustand beim Fahren.
- Spielername, Server-ID, Spieldatum und -uhrzeit, Himmelsrichtung und Straßenname.
- HUD per F10 oder `/hud` ein- und ausblendbar.
- Ausblenden im Pausemenü und beim Tod.

## Installation

1. Den Ordner `nexus-hud` in den FiveM-Ordner `resources` kopieren.
2. In `server.cfg` nach den Framework-Ressourcen starten:

   ```cfg
   ensure qb-core
   ensure nexus-hud
   ```

   Oder mit ESX:

   ```cfg
   ensure es_extended
   ensure esx_status
   ensure nexus-hud
   ```

3. Optional `Config.Framework` in `config.lua` auf `qb` oder `esx` setzen. `auto` erkennt das gestartete Framework.
4. Server starten oder `refresh` und `ensure nexus-hud` in der Serverkonsole ausführen.

Bei ESX müssen `es_extended` und `esx_status` gestartet sein, damit Hunger und Durst angezeigt werden. Andere Status-Systeme liefern diese Werte nicht automatisch.

## Vorschau

Die interaktive Browser-Vorschau unter `/hud-preview` simuliert Spielwerte. Die NUI im Ressourcenordner empfängt während des Spiels echte Werte aus `client.lua`.

const hud = document.getElementById("hud");
const fields = {
  health: ["health-bar", "health-value"],
  armor: ["armor-bar", "armor-value"],
  hunger: ["hunger-bar", "hunger-value"],
  thirst: ["thirst-bar", "thirst-value"],
  stamina: ["stamina-bar", "stamina-value"],
};

function setPercent(name, value) {
  const item = document.querySelector(`[data-status="${name}"]`);
  const elements = fields[name];
  if (!item || !elements) return;
  const [barId, valueId] = elements;
  const bar = document.getElementById(barId);
  const number = document.getElementById(valueId);

  if (value === null || value === undefined || Number.isNaN(Number(value))) {
    item.hidden = true;
    return;
  }

  const percent = Math.max(0, Math.min(100, Math.round(Number(value))));
  const circumference = 119.38;
  item.hidden = false;
  bar.style.strokeDashoffset = `${circumference * (1 - percent / 100)}`;
  number.textContent = `${percent}`;
}

function updateHud(data) {
  hud.classList.toggle("is-hidden", !data.visible);
  document.getElementById("player-info").hidden = !data.showPlayerInfo;

  for (const key of Object.keys(fields)) {
    setPercent(key, data[key]);
  }

  const voice = document.querySelector(".voice-item");
  voice.classList.toggle("is-talking", Boolean(data.talking));
  document.getElementById("voice-status").textContent = data.talking ? "SENDEN" : "BEREIT";
  document.getElementById("voice-symbol").classList.toggle("is-talking", Boolean(data.talking));

  document.getElementById("player-name").textContent = data.playerName || "Citizen";
  document.getElementById("player-id").textContent = String(data.playerId ?? 0).padStart(4, "0");
  document.getElementById("street").textContent = data.street || "Los Santos";
  document.getElementById("vehicle-street").textContent = (data.street || "LOS SANTOS").toLocaleUpperCase();
  document.getElementById("direction").textContent = data.direction || "N";
  document.getElementById("game-date").textContent = data.date || "";
  document.getElementById("game-time").textContent = data.time || "00:00";

  const vehiclePanel = document.getElementById("vehicle-panel");
  vehiclePanel.classList.toggle("is-visible", Boolean(data.isVehicle));
  document.getElementById("speed-value").textContent = `${Math.max(0, Math.round(data.speed || 0))}`;
  document.getElementById("fuel-value").textContent = `${Math.max(0, Math.round(data.fuel || 0))}%`;
  document.getElementById("fuel-bar").style.width = `${Math.max(0, Math.min(100, Number(data.fuel) || 0))}%`;
  document.getElementById("engine-bar").style.width = `${Math.max(0, Math.min(100, Number(data.engine) || 0))}%`;
  document.getElementById("gear-value").textContent = data.gear > 0 ? `${data.gear}` : "R";
  document.getElementById("speed-ring-fill").style.strokeDashoffset = `${165 + Math.max(0, 1 - Math.min(Number(data.speed) || 0, 240) / 240) * 150}`;
}

window.addEventListener("message", (event) => {
  const data = event.data;
  if (!data || typeof data !== "object") return;
  if (data.action === "update") updateHud(data);
  if (data.action === "visibility") hud.classList.toggle("is-hidden", !data.visible);
});

import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  EmbedBuilder,
  MessageFlags,
  PermissionFlagsBits,
  SlashCommandBuilder,
} from "discord.js";

const OPEN_BUTTON_PREFIX = "nexus-ticket:create";
const CLOSE_BUTTON_ID = "nexus-ticket:close";
const TOPIC_PREFIX = "nexus-ticket:v1";
const openTicketCreations = new Set();

const ticketTypes = {
  support: { label: "Support", emoji: "🛟", channelPrefix: "support" },
  bug: { label: "Bug melden", emoji: "🪲", channelPrefix: "bug" },
  other: { label: "Sonstige Anfrage", emoji: "💬", channelPrefix: "anfrage" },
};

export const ticketPanelCommand = new SlashCommandBuilder()
  .setName("ticket-panel")
  .setDescription("Erstellt ein Panel zum Öffnen privater Support-Tickets.")
  .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
  .addChannelOption((option) =>
    option
      .setName("kanal")
      .setDescription("Textkanal, in den das Ticket-Panel gesendet wird")
      .addChannelTypes(ChannelType.GuildText)
      .setRequired(true),
  )
  .addRoleOption((option) =>
    option
      .setName("support-rolle")
      .setDescription("Rolle, die die privaten Tickets sehen und beantworten darf")
      .setRequired(true),
  )
  .addChannelOption((option) =>
    option
      .setName("ticket-kategorie")
      .setDescription("Optionale Kategorie für neu erstellte Tickets")
      .addChannelTypes(ChannelType.GuildCategory),
  );

export const ticketCommands = [ticketPanelCommand.toJSON()];

function makeTicketTopic({ ownerId, supportRoleId, kind, status = "open" }) {
  return `${TOPIC_PREFIX}|owner=${ownerId}|support=${supportRoleId}|kind=${kind}|status=${status}`;
}

function parseTicketTopic(topic) {
  if (!topic?.startsWith(`${TOPIC_PREFIX}|`)) return null;

  const values = Object.fromEntries(
    topic.slice(TOPIC_PREFIX.length + 1).split("|").map((part) => {
      const separator = part.indexOf("=");
      return separator === -1 ? [part, ""] : [part.slice(0, separator), part.slice(separator + 1)];
    }),
  );

  if (
    !values.owner ||
    !values.support ||
    !Object.hasOwn(ticketTypes, values.kind) ||
    !["open", "closed"].includes(values.status)
  ) {
    return null;
  }

  return {
    ownerId: values.owner,
    supportRoleId: values.support,
    kind: values.kind,
    status: values.status,
  };
}

function getOpenPanelComponents(supportRoleId, categoryId) {
  const row = new ActionRowBuilder().addComponents(
    ...Object.entries(ticketTypes).map(([kind, type]) =>
      new ButtonBuilder()
        .setCustomId(`${OPEN_BUTTON_PREFIX}:${kind}:${supportRoleId}:${categoryId ?? "none"}`)
        .setLabel(type.label)
        .setEmoji(type.emoji)
        .setStyle(kind === "support" ? ButtonStyle.Primary : ButtonStyle.Secondary),
    ),
  );
  return [row];
}

function getCloseComponents(disabled = false) {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(CLOSE_BUTTON_ID)
        .setLabel(disabled ? "Ticket geschlossen" : "Ticket schließen")
        .setEmoji("🔒")
        .setStyle(ButtonStyle.Danger)
        .setDisabled(disabled),
    ),
  ];
}

async function replyWithError(interaction, error) {
  console.error(`Nexus Ticket System: ${error.message}`);
  const message = "Das Ticket-System konnte die Aktion nicht abschließen. Prüfe die Bot-Rechte und das Serverprotokoll.";
  if (interaction.deferred || interaction.replied) {
    await interaction.editReply(message);
  } else {
    await interaction.reply({ content: message, flags: MessageFlags.Ephemeral });
  }
}

async function handlePanelCommand(interaction) {
  if (!interaction.inGuild()) {
    await interaction.reply({ content: "Das Ticket-Panel kann nur auf einem Server erstellt werden.", flags: MessageFlags.Ephemeral });
    return;
  }

  if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
    await interaction.reply({ content: "Du benötigst die Server-Verwalten-Berechtigung, um ein Ticket-Panel zu erstellen.", flags: MessageFlags.Ephemeral });
    return;
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const panelChannel = interaction.options.getChannel("kanal", true);
  const supportRole = interaction.options.getRole("support-rolle", true);
  const category = interaction.options.getChannel("ticket-kategorie");
  const botMember = interaction.guild.members.me ?? await interaction.guild.members.fetchMe();

  if (supportRole.id === interaction.guild.id) {
    await interaction.editReply("Wähle eine eigene Support-Rolle, nicht @everyone.");
    return;
  }

  if (!panelChannel.isTextBased() || panelChannel.type !== ChannelType.GuildText) {
    await interaction.editReply("Wähle einen normalen Server-Textkanal für das Panel.");
    return;
  }

  if (category && category.type !== ChannelType.GuildCategory) {
    await interaction.editReply("Die Ticket-Kategorie ist ungültig. Wähle eine Server-Kategorie oder lass das Feld leer.");
    return;
  }

  if (!botMember.permissionsIn(panelChannel).has([
    PermissionFlagsBits.ViewChannel,
    PermissionFlagsBits.SendMessages,
    PermissionFlagsBits.EmbedLinks,
  ])) {
    await interaction.editReply("Dem Bot fehlen im Panel-Kanal die Rechte zum Ansehen, Senden oder Einbetten von Nachrichten.");
    return;
  }

  const embed = new EmbedBuilder()
    .setColor(0x3288ee)
    .setTitle("Nexus Support")
    .setDescription("Wähle unten den passenden Bereich. Der Bot erstellt einen privaten Kanal für dich und das Support-Team.")
    .addFields(
      { name: "Support", value: "Fragen und allgemeine Hilfe", inline: true },
      { name: "Bug melden", value: "Fehler oder technische Probleme", inline: true },
      { name: "Sonstige Anfrage", value: "Andere Anliegen", inline: true },
    )
    .setFooter({ text: "Bitte öffne nur ein Ticket pro Anliegen." });

  await panelChannel.send({
    embeds: [embed],
    components: getOpenPanelComponents(supportRole.id, category?.id),
  });
  await interaction.editReply(`Das Ticket-Panel wurde in ${panelChannel} erstellt.`);
}

function parseCreateButton(customId) {
  const match = /^nexus-ticket:create:(support|bug|other):(\d{17,20}):(none|\d{17,20})$/.exec(customId);
  if (!match) return null;
  return { kind: match[1], supportRoleId: match[2], categoryId: match[3] === "none" ? null : match[3] };
}

function makeChannelSlug(displayName) {
  const slug = displayName
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 70);
  return slug || "mitglied";
}

async function handleCreateButton(interaction, settings) {
  if (!interaction.inGuild()) {
    await interaction.reply({ content: "Tickets können nur auf einem Server geöffnet werden.", flags: MessageFlags.Ephemeral });
    return;
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });
  const lockKey = `${interaction.guildId}:${interaction.user.id}`;
  if (openTicketCreations.has(lockKey)) {
    await interaction.editReply("Dein Ticket wird bereits erstellt. Bitte warte kurz.");
    return;
  }
  openTicketCreations.add(lockKey);

  try {
    const supportRole = await interaction.guild.roles.fetch(settings.supportRoleId);
    if (!supportRole) {
      await interaction.editReply("Die Support-Rolle dieses Panels existiert nicht mehr. Bitte erstelle das Panel erneut.");
      return;
    }

    const category = settings.categoryId ? await interaction.guild.channels.fetch(settings.categoryId) : null;
    if (settings.categoryId && (!category || category.type !== ChannelType.GuildCategory)) {
      await interaction.editReply("Die Ticket-Kategorie dieses Panels existiert nicht mehr. Bitte erstelle das Panel erneut.");
      return;
    }

    const botMember = interaction.guild.members.me ?? await interaction.guild.members.fetchMe();
    if (!botMember.permissions.has(PermissionFlagsBits.ManageChannels)) {
      await interaction.editReply("Dem Bot fehlt die Server-Berechtigung Kanäle verwalten.");
      return;
    }

    const channels = await interaction.guild.channels.fetch();
    const currentTicket = channels.find((channel) => {
      if (!channel || channel.type !== ChannelType.GuildText) return false;
      const ticket = parseTicketTopic(channel.topic);
      return ticket?.ownerId === interaction.user.id && ticket.status === "open";
    });
    if (currentTicket) {
      await interaction.editReply(`Du hast bereits ein offenes Ticket: ${currentTicket}`);
      return;
    }

    const kind = ticketTypes[settings.kind];
    const member = await interaction.guild.members.fetch(interaction.user.id);
    const channel = await interaction.guild.channels.create({
      name: `ticket-${kind.channelPrefix}-${makeChannelSlug(member.displayName)}`.slice(0, 100),
      type: ChannelType.GuildText,
      ...(category ? { parent: category.id } : {}),
      topic: makeTicketTopic({
        ownerId: interaction.user.id,
        supportRoleId: supportRole.id,
        kind: settings.kind,
      }),
      permissionOverwrites: [
        { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
        {
          id: interaction.user.id,
          allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
        },
        {
          id: supportRole.id,
          allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
        },
        {
          id: botMember.id,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.ReadMessageHistory,
            PermissionFlagsBits.ManageChannels,
          ],
        },
      ],
      reason: `Nexus Ticket System: ${kind.label} von ${interaction.user.tag}`,
    });

    try {
      await channel.send({
        content: `<@${interaction.user.id}>`,
        embeds: [
          new EmbedBuilder()
            .setColor(0x3288ee)
            .setTitle(`Ticket: ${kind.label}`)
            .setDescription("Beschreibe dein Anliegen. Ein Mitglied des Support-Teams meldet sich hier.")
            .addFields({ name: "Support-Team", value: `<@&${supportRole.id}>` })
            .setFooter({ text: "Schließe das Ticket über den Button, wenn dein Anliegen gelöst ist." }),
        ],
        components: getCloseComponents(),
        allowedMentions: { users: [interaction.user.id], roles: [] },
      });
    } catch (error) {
      try {
        await channel.delete("Nexus Ticket System: Ticket-Nachricht konnte nicht gesendet werden");
      } catch (cleanupError) {
        console.error(`Nexus Ticket System: Ticket-Nachricht fehlgeschlagen und ${channel.id} konnte nicht entfernt werden.`, cleanupError);
        await interaction.editReply(`Der Ticket-Kanal ${channel} wurde erstellt, aber seine Startnachricht konnte nicht gesendet werden. Ein Administrator muss den Kanal prüfen oder entfernen.`);
        return;
      }
      throw error;
    }

    await interaction.editReply(`Dein privates Ticket wurde erstellt: ${channel}`);
  } finally {
    openTicketCreations.delete(lockKey);
  }
}

async function handleCloseButton(interaction) {
  if (!interaction.inGuild() || !interaction.channel || interaction.channel.type !== ChannelType.GuildText) {
    await interaction.reply({ content: "Dieser Button funktioniert nur in einem Nexus-Ticket-Kanal.", flags: MessageFlags.Ephemeral });
    return;
  }

  const ticket = parseTicketTopic(interaction.channel.topic);
  if (!ticket) {
    await interaction.reply({ content: "Dieser Kanal ist kein gültiger Nexus-Ticket-Kanal.", flags: MessageFlags.Ephemeral });
    return;
  }
  if (ticket.status === "closed") {
    await interaction.reply({ content: "Dieses Ticket ist bereits geschlossen.", flags: MessageFlags.Ephemeral });
    return;
  }

  const member = await interaction.guild.members.fetch(interaction.user.id);
  const canClose = ticket.ownerId === interaction.user.id ||
    member.roles.cache.has(ticket.supportRoleId) ||
    member.permissions.has(PermissionFlagsBits.ManageChannels);
  if (!canClose) {
    await interaction.reply({ content: "Nur die Person, die das Ticket geöffnet hat, das Support-Team oder die Server-Administration kann es schließen.", flags: MessageFlags.Ephemeral });
    return;
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  await interaction.channel.permissionOverwrites.edit(ticket.ownerId, {
    SendMessages: false,
  });
  try {
    await interaction.channel.setTopic(makeTicketTopic({ ...ticket, status: "closed" }));
  } catch (error) {
    try {
      await interaction.channel.permissionOverwrites.edit(ticket.ownerId, { SendMessages: true });
    } catch (rollbackError) {
      console.error(`Nexus Ticket System: Ticket ${interaction.channel.id} konnte nach fehlgeschlagenem Schließen nicht zurückgesetzt werden.`, rollbackError);
    }
    throw error;
  }

  let messageUpdated = true;
  try {
    await interaction.message.edit({ components: getCloseComponents(true) });
  } catch (error) {
    messageUpdated = false;
    console.error(`Nexus Ticket System: Ticket ${interaction.channel.id} wurde geschlossen, aber der Button konnte nicht aktualisiert werden.`, error);
  }

  await interaction.editReply(
    messageUpdated
      ? "Ticket geschlossen. Der Kanal bleibt für die Dokumentation schreibgeschützt erhalten."
      : "Ticket geschlossen und für dich schreibgeschützt. Die Schaltfläche konnte nicht aktualisiert werden; ein Administrator kann sie entfernen.",
  );
}

export async function handleTicketInteraction(interaction) {
  const isPanelCommand = interaction.isChatInputCommand() && interaction.commandName === "ticket-panel";
  const createSettings = interaction.isButton() ? parseCreateButton(interaction.customId) : null;
  const isCloseButton = interaction.isButton() && interaction.customId === CLOSE_BUTTON_ID;

  if (!isPanelCommand && !createSettings && !isCloseButton) return false;

  try {
    if (isPanelCommand) await handlePanelCommand(interaction);
    else if (createSettings) await handleCreateButton(interaction, createSettings);
    else await handleCloseButton(interaction);
  } catch (error) {
    await replyWithError(interaction, error);
  }
  return true;
}

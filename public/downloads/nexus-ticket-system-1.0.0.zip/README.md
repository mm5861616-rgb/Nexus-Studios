# Nexus Ticket System – Erweiterungsscript

Das Nexus Ticket System ist ein **Add-on-Script für vorhandene Discord.js-v14-Bots**. Es stellt `/ticket-panel` und die Button-Handler für private Support-Tickets bereit. Es ist kein eigener Bot und enthält kein Hosting. Das Script verwendet ES-Module; dein Bot muss `"type": "module"` verwenden oder die Importe für CommonJS anpassen.

Die vollständige Nexus-Bot-V1-Ressource enthält das Add-on bereits. Wenn du das Ticket-System einem anderen kompatiblen Bot hinzufügen willst, kopiere `src/ticket-system.js` in dessen `src`-Ordner und integriere Befehl und Interaktionshandler wie unten beschrieben. Eine Bot-Plattform muss benutzerdefinierten Discord.js-Code und Slash-Befehle unterstützen; ein Token-Eingabefeld allein reicht nicht.

## Funktionen

- `/ticket-panel kanal support-rolle [ticket-kategorie]` erstellt ein Panel mit **Support**, **Bug melden** und **Sonstige Anfrage**.
- Beim Klick entsteht ein privater Textkanal für die Person, die das Ticket geöffnet hat, die konfigurierte Support-Rolle und den Bot.
- Pro Person ist jeweils ein offenes Ticket zulässig.
- Die eröffnende Person, das Support-Team und Server-Administratoren können ein Ticket schließen.
- Geschlossene Tickets bleiben als schreibgeschützte Kanäle erhalten. Es gibt keine Transkripte und keine automatische Löschung.
- Keine privilegierten Gateway-Intents und keine Datenbank erforderlich. Ticketbesitzer, Support-Rolle, Anliegen und Status sind im Kanal-Thema gespeichert.

## Voraussetzungen und Discord-Rechte

- Bestehender Bot mit Node.js 20+ und `discord.js` v14.
- Slash-Command-Scope `applications.commands`.
- Bot-Rechte: **Kanäle ansehen**, **Kanäle verwalten**, **Nachrichten senden**, **Links einbetten** und **Nachrichtenverlauf ansehen**.
- Mitglieder, die `/ticket-panel` verwenden, benötigen **Server verwalten**.
- Beim Setup wählst du eine Support-Rolle aus. Setze die Bot-Rolle in der Server-Rollenliste oberhalb der Support-Rolle und der Ticketkanäle, die der Bot verwalten soll.
- Aktiviere keine Administrator-Berechtigung nur für dieses Script.

## Installation in Nexus Bot V1

Die aktuelle Nexus-Bot-V1-ZIP enthält bereits `src/ticket-system.js`, den `/ticket-panel`-Befehl und dessen Button-Handler. Aktualisiere die Bot-Dateien, installiere die Abhängigkeiten und registriere die Slash-Befehle gemäß der Nexus-Bot-V1-README.

## Integration in einen anderen Discord.js-v14-Bot

1. Kopiere `src/ticket-system.js` in den `src`-Ordner deines bestehenden Bots.
2. Füge den Befehl zur bisherigen Befehlsliste hinzu. Serialisiere den Builder erst danach mit `.toJSON()`:

   ```js
   import { ticketPanelCommand } from "./ticket-system.js";

   const commands = [
     existingCommand,
     ticketPanelCommand,
   ].map((command) => command.toJSON());
   ```

3. Registriere `commands` wie bisher über Discord's REST API. Registriere nach jeder Änderung an der Slash-Command-Liste die Befehle erneut.
4. Leite alle Discord-Interaktionen an den Add-on-Handler weiter, bevor du nicht-Chat-Interaktionen ignorierst:

   ```js
   import { handleTicketInteraction } from "./ticket-system.js";

   client.on("interactionCreate", async (interaction) => {
     if (await handleTicketInteraction(interaction)) return;
     if (!interaction.isChatInputCommand()) return;

     // Hier die bisherigen Chat-Commands verarbeiten.
   });
   ```

5. Starte deinen Bot neu. `/ticket-panel` auswählen, einen sichtbaren Textkanal und eine Support-Rolle angeben. Eine Ticket-Kategorie ist optional.

Wenn deine Bot-Plattform nur einen Token annimmt und keine eigenen Discord.js-Scripts laden oder ausführen lässt, kann sie dieses Add-on nicht nutzen.

## Hinweise und Grenzen

- Discords Rollenposition und Kanalrechte gelten weiterhin. Der Bot kann keine Person moderieren oder berechtigen, deren Rollen über seiner eigenen liegen.
- Discord-Administratoren können aufgrund ihrer Administrator-Rechte private Ticketkanäle weiterhin sehen.
- Geschlossene Tickets bleiben erhalten. Richte bei Bedarf eine eigene Aufbewahrungsregel ein und lösche alte Kanäle manuell.
- Dieses Add-on wurde nicht mit einem echten Discord-Server verbunden. Teste es zuerst auf einem privaten Testserver.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local StarterGui = game:GetService("StarterGui")
local UserInputService = game:GetService("UserInputService")

local player = Players.LocalPlayer
local remotes = ReplicatedStorage:WaitForChild("NexusAdminRemotes")
local adminRequest = remotes:WaitForChild("AdminRequest")
local adminNotice = remotes:WaitForChild("AdminNotice")
local panelToggleKey = Enum.KeyCode[remotes:GetAttribute("PanelToggleKey") or "RightShift"]

local COLORS = {
	background = Color3.fromRGB(8, 14, 24),
	panel = Color3.fromRGB(14, 24, 39),
	panelRaised = Color3.fromRGB(19, 33, 52),
	border = Color3.fromRGB(39, 61, 86),
	blue = Color3.fromRGB(47, 126, 224),
	blueLight = Color3.fromRGB(122, 184, 255),
	text = Color3.fromRGB(229, 239, 252),
	muted = Color3.fromRGB(147, 166, 190),
	red = Color3.fromRGB(190, 69, 84),
	green = Color3.fromRGB(50, 151, 119),
}

local screen = Instance.new("ScreenGui")
screen.Name = "NexusAdminPanel"
screen.ResetOnSpawn = false
screen.IgnoreGuiInset = false
screen.DisplayOrder = 25
screen.Enabled = false
screen.Parent = player:WaitForChild("PlayerGui")

local overlay = Instance.new("Frame")
overlay.Name = "Overlay"
overlay.Size = UDim2.fromScale(1, 1)
overlay.BackgroundColor3 = Color3.new(0, 0, 0)
overlay.BackgroundTransparency = 0.38
overlay.Parent = screen

local main = Instance.new("Frame")
main.Name = "Main"
main.AnchorPoint = Vector2.new(0.5, 0.5)
main.Position = UDim2.fromScale(0.5, 0.5)
main.Size = UDim2.new(0.88, 0, 0.8, 0)
main.BackgroundColor3 = COLORS.background
main.BorderSizePixel = 0
main.Parent = overlay
local mainCorner = Instance.new("UICorner")
mainCorner.CornerRadius = UDim.new(0, 12)
mainCorner.Parent = main
local mainStroke = Instance.new("UIStroke")
mainStroke.Color = COLORS.border
mainStroke.Transparency = 0.15
mainStroke.Parent = main

local sizeConstraint = Instance.new("UISizeConstraint")
sizeConstraint.MinSize = Vector2.new(340, 360)
sizeConstraint.MaxSize = Vector2.new(1000, 680)
sizeConstraint.Parent = main

local header = Instance.new("Frame")
header.Size = UDim2.new(1, 0, 0, 54)
header.BackgroundColor3 = COLORS.panel
header.BorderSizePixel = 0
header.Parent = main
local headerCorner = Instance.new("UICorner")
headerCorner.CornerRadius = UDim.new(0, 12)
headerCorner.Parent = header

local function label(parent, text, position, size, textSize, color)
	local object = Instance.new("TextLabel")
	object.BackgroundTransparency = 1
	object.Position = position
	object.Size = size
	object.Font = Enum.Font.Gotham
	object.Text = text
	object.TextSize = textSize or 13
	object.TextColor3 = color or COLORS.text
	object.TextXAlignment = Enum.TextXAlignment.Left
	object.TextYAlignment = Enum.TextYAlignment.Center
	object.TextWrapped = true
	object.Parent = parent
	return object
end

label(header, "NEXUS  /  ADMIN & MODERATION", UDim2.new(0, 18, 0, 0), UDim2.new(1, -130, 1, 0), 14, COLORS.blueLight).Font = Enum.Font.GothamBold

local closeButton = Instance.new("TextButton")
closeButton.AnchorPoint = Vector2.new(1, 0.5)
closeButton.Position = UDim2.new(1, -12, 0.5, 0)
closeButton.Size = UDim2.fromOffset(34, 32)
closeButton.BackgroundColor3 = COLORS.panelRaised
closeButton.BorderSizePixel = 0
closeButton.Text = "×"
closeButton.TextSize = 20
closeButton.TextColor3 = COLORS.text
closeButton.Font = Enum.Font.Gotham
closeButton.Parent = header
local closeCorner = Instance.new("UICorner")
closeCorner.CornerRadius = UDim.new(0, 6)
closeCorner.Parent = closeButton

local content = Instance.new("Frame")
content.Position = UDim2.new(0, 12, 0, 66)
content.Size = UDim2.new(1, -24, 1, -78)
content.BackgroundTransparency = 1
content.Parent = main

local left = Instance.new("Frame")
left.Size = UDim2.new(0.34, -6, 1, 0)
left.BackgroundColor3 = COLORS.panel
left.BorderSizePixel = 0
left.Parent = content
local leftCorner = Instance.new("UICorner")
leftCorner.CornerRadius = UDim.new(0, 8)
leftCorner.Parent = left

local right = Instance.new("Frame")
right.Position = UDim2.new(0.34, 6, 0, 0)
right.Size = UDim2.new(0.66, -6, 1, 0)
right.BackgroundColor3 = COLORS.panel
right.BorderSizePixel = 0
right.Parent = content
local rightCorner = Instance.new("UICorner")
rightCorner.CornerRadius = UDim.new(0, 8)
rightCorner.Parent = right

local playerHeading = label(left, "ONLINE- SPIELER", UDim2.new(0, 12, 0, 9), UDim2.new(0.65, -12, 0, 28), 10, COLORS.muted)
playerHeading.Font = Enum.Font.GothamBold

local refreshButton = Instance.new("TextButton")
refreshButton.Position = UDim2.new(0.67, 0, 0, 8)
refreshButton.Size = UDim2.new(0.3, -8, 0, 28)
refreshButton.BackgroundColor3 = COLORS.panelRaised
refreshButton.BorderSizePixel = 0
refreshButton.Text = "Aktualisieren"
refreshButton.TextSize = 9
refreshButton.TextColor3 = COLORS.blueLight
refreshButton.Font = Enum.Font.GothamMedium
refreshButton.Parent = left
local refreshCorner = Instance.new("UICorner")
refreshCorner.CornerRadius = UDim.new(0, 5)
refreshCorner.Parent = refreshButton

local playersList = Instance.new("ScrollingFrame")
playersList.Position = UDim2.new(0, 8, 0, 43)
playersList.Size = UDim2.new(1, -16, 1, -51)
playersList.BackgroundTransparency = 1
playersList.BorderSizePixel = 0
playersList.ScrollBarThickness = 3
playersList.ScrollBarImageColor3 = COLORS.border
playersList.AutomaticCanvasSize = Enum.AutomaticSize.Y
playersList.CanvasSize = UDim2.new()
playersList.Parent = left
local playersLayout = Instance.new("UIListLayout")
playersLayout.Padding = UDim.new(0, 5)
playersLayout.SortOrder = Enum.SortOrder.LayoutOrder
playersLayout.Parent = playersList

label(right, "AUSGEWÄHLTES MITGLIED / ROBLOX USER ID", UDim2.new(0, 13, 0, 8), UDim2.new(1, -26, 0, 20), 9, COLORS.muted).Font = Enum.Font.GothamBold

local userIdBox = Instance.new("TextBox")
userIdBox.Position = UDim2.new(0, 12, 0, 31)
userIdBox.Size = UDim2.new(1, -24, 0, 34)
userIdBox.BackgroundColor3 = COLORS.background
userIdBox.BorderSizePixel = 0
userIdBox.PlaceholderText = "Spieler links anklicken oder User-ID eingeben"
userIdBox.PlaceholderColor3 = COLORS.muted
userIdBox.Text = ""
userIdBox.TextColor3 = COLORS.text
userIdBox.TextSize = 11
userIdBox.Font = Enum.Font.Gotham
userIdBox.ClearTextOnFocus = false
userIdBox.Parent = right
local userIdCorner = Instance.new("UICorner")
userIdCorner.CornerRadius = UDim.new(0, 5)
userIdCorner.Parent = userIdBox

local reasonBox = Instance.new("TextBox")
reasonBox.Position = UDim2.new(0, 12, 0, 72)
reasonBox.Size = UDim2.new(1, -24, 0, 34)
reasonBox.BackgroundColor3 = COLORS.background
reasonBox.BorderSizePixel = 0
reasonBox.PlaceholderText = "Grund (maximal 300 Zeichen)"
reasonBox.PlaceholderColor3 = COLORS.muted
reasonBox.Text = ""
reasonBox.TextColor3 = COLORS.text
reasonBox.TextSize = 11
reasonBox.Font = Enum.Font.Gotham
reasonBox.ClearTextOnFocus = false
reasonBox.Parent = right
local reasonCorner = Instance.new("UICorner")
reasonCorner.CornerRadius = UDim.new(0, 5)
reasonCorner.Parent = reasonBox

local status = label(right, "Wähle einen Spieler oder gib eine User-ID ein.", UDim2.new(0, 12, 0, 111), UDim2.new(1, -24, 0, 36), 10, COLORS.muted)

local actions = Instance.new("Frame")
actions.Position = UDim2.new(0, 12, 0, 151)
actions.Size = UDim2.new(1, -24, 0, 37)
actions.BackgroundTransparency = 1
actions.Parent = right
local actionLayout = Instance.new("UIGridLayout")
actionLayout.CellPadding = UDim2.fromOffset(5, 5)
actionLayout.CellSize = UDim2.new(0.2, -4, 0, 34)
actionLayout.SortOrder = Enum.SortOrder.LayoutOrder
actionLayout.Parent = actions

local logHeading = label(right, "LETZTE MODERATIONSAKTIONEN", UDim2.new(0, 13, 0, 198), UDim2.new(1, -26, 0, 22), 9, COLORS.muted)
logHeading.Font = Enum.Font.GothamBold

local logsList = Instance.new("ScrollingFrame")
logsList.Position = UDim2.new(0, 12, 0, 223)
logsList.Size = UDim2.new(1, -24, 1, -232)
logsList.BackgroundColor3 = COLORS.background
logsList.BackgroundTransparency = 0.15
logsList.BorderSizePixel = 0
logsList.ScrollBarThickness = 3
logsList.ScrollBarImageColor3 = COLORS.border
logsList.AutomaticCanvasSize = Enum.AutomaticSize.Y
logsList.CanvasSize = UDim2.new()
logsList.Parent = right
local logsCorner = Instance.new("UICorner")
logsCorner.CornerRadius = UDim.new(0, 5)
logsCorner.Parent = logsList
local logsLayout = Instance.new("UIListLayout")
logsLayout.Padding = UDim.new(0, 4)
logsLayout.SortOrder = Enum.SortOrder.LayoutOrder
logsLayout.Parent = logsList

local actionButtons = {}
local actionDefinitions = {
	{ name = "Warn", color = COLORS.blue, label = "Warn" },
	{ name = "Kick", color = COLORS.red, label = "Kick" },
	{ name = "Ban", color = COLORS.red, label = "Ban" },
	{ name = "Unban", color = COLORS.green, label = "Unban" },
	{ name = "GetWarnings", color = COLORS.panelRaised, label = "Warnungen" },
}

local function clearList(container)
	for _, child in ipairs(container:GetChildren()) do
		if not child:IsA("UIListLayout") then
			child:Destroy()
		end
	end
end

local function makeButton(parent, text, color)
	local button = Instance.new("TextButton")
	button.BackgroundColor3 = color
	button.BorderSizePixel = 0
	button.Text = text
	button.TextColor3 = COLORS.text
	button.TextSize = 10
	button.Font = Enum.Font.GothamBold
	button.AutoButtonColor = true
	button.Parent = parent
	local corner = Instance.new("UICorner")
	corner.CornerRadius = UDim.new(0, 5)
	corner.Parent = button
	return button
end

local function displayTime(timestamp)
	if typeof(timestamp) ~= "number" then
		return "Unbekannte Zeit"
	end
	return DateTime.fromUnixTimestampMillis(timestamp):FormatLocalTime("YYYY-MM-DD HH:mm", "en-us")
end

local function refreshDashboard()
	status.Text = "Lade Spieler und Moderationsprotokoll..."
	local success, response = pcall(function()
		return adminRequest:InvokeServer({ type = "GetDashboard" })
	end)
	if not success or typeof(response) ~= "table" or not response.ok then
		status.Text = if typeof(response) == "table" then response.error else "Serveranfrage fehlgeschlagen."
		status.TextColor3 = COLORS.red
		return
	end

	status.Text = "Aktionen werden serverseitig geprüft. Offline-Bans sind über eine User-ID möglich."
	status.TextColor3 = COLORS.muted
	clearList(playersList)
	for _, entry in ipairs(response.data.players) do
		local button = makeButton(playersList, entry.name .. "  ·  " .. tostring(entry.userId), COLORS.panelRaised)
		button.Size = UDim2.new(1, 0, 0, 32)
		button.TextXAlignment = Enum.TextXAlignment.Left
		button.TextTruncate = Enum.TextTruncate.AtEnd
		button.Activated:Connect(function()
			userIdBox.Text = tostring(entry.userId)
			status.Text = "Ausgewählt: " .. entry.name
			status.TextColor3 = COLORS.blueLight
		end)
	end
	if #response.data.players == 0 then
		label(playersList, "Keine Spieler online.", UDim2.new(), UDim2.new(1, 0, 0, 28), 10, COLORS.muted)
	end

	clearList(logsList)
	for _, entry in ipairs(response.data.logs) do
		local text = string.format(
			"%s  ·  %s → %s\n%s  ·  %s",
			tostring(entry.action),
			tostring(entry.actorName),
			tostring(entry.targetName),
			displayTime(entry.timestamp),
			tostring(entry.reason)
		)
		local row = label(logsList, text, UDim2.new(0, 7, 0, 0), UDim2.new(1, -14, 0, 48), 9, COLORS.muted)
		row.TextYAlignment = Enum.TextYAlignment.Top
	end
	if #response.data.logs == 0 then
		label(logsList, "Noch keine protokollierten Aktionen.", UDim2.new(0, 7, 0, 0), UDim2.new(1, -14, 0, 26), 9, COLORS.muted)
	end
end

for index, definition in ipairs(actionDefinitions) do
	local button = makeButton(actions, definition.label, definition.color)
	button.LayoutOrder = index
	actionButtons[definition.name] = button
	button.Activated:Connect(function()
		local targetUserId = tonumber(userIdBox.Text)
		if not targetUserId or targetUserId <= 0 or targetUserId % 1 ~= 0 then
			status.Text = "Gib eine gültige Roblox User-ID ein."
			status.TextColor3 = COLORS.red
			return
		end
		button.Active = false
		status.Text = if definition.name == "GetWarnings" then "Lade Warnungen..." else "Führe Aktion aus..."
		status.TextColor3 = COLORS.muted
		local success, response = pcall(function()
			if definition.name == "GetWarnings" then
				return adminRequest:InvokeServer({
					type = "GetWarnings",
					targetUserId = tostring(targetUserId),
				})
			end
			return adminRequest:InvokeServer({
				type = "Action",
				action = definition.name,
				payload = {
					targetUserId = tostring(targetUserId),
					reason = string.sub(reasonBox.Text, 1, 300),
				},
			})
		end)
		button.Active = true
		if not success or typeof(response) ~= "table" then
			status.Text = "Serveranfrage fehlgeschlagen. Prüfe das Serverprotokoll."
			status.TextColor3 = COLORS.red
			return
		end
		if definition.name == "GetWarnings" and response.ok then
			clearList(logsList)
			if #response.warnings == 0 then
				label(logsList, "Für diese User-ID gibt es keine gespeicherten Warnungen.", UDim2.new(0, 7, 0, 0), UDim2.new(1, -14, 0, 38), 9, COLORS.muted)
			else
				for _, warning in ipairs(response.warnings) do
					local row = label(
						logsList,
						displayTime(warning.timestamp) .. "\n" .. tostring(warning.reason),
						UDim2.new(0, 7, 0, 0),
						UDim2.new(1, -14, 0, 42),
						9,
						COLORS.muted
					)
					row.TextYAlignment = Enum.TextYAlignment.Top
				end
			end
			status.Text = "Warnungsverlauf für User-ID " .. tostring(targetUserId) .. " geladen."
			status.TextColor3 = COLORS.green
			button.Active = true
			return
		end
		status.Text = response.message or response.error or "Unbekannte Serverantwort."
		status.TextColor3 = if response.ok then COLORS.green else COLORS.red
		refreshDashboard()
	end)
end

refreshButton.Activated:Connect(refreshDashboard)
closeButton.Activated:Connect(function()
	screen.Enabled = false
end)

UserInputService.InputBegan:Connect(function(input, processed)
	if processed then
		return
	end
	if input.KeyCode == panelToggleKey then
		screen.Enabled = not screen.Enabled
		if screen.Enabled then
			refreshDashboard()
		end
	end
end)

adminNotice.OnClientEvent:Connect(function(message)
	if message == "OPEN_PANEL" then
		screen.Enabled = true
		refreshDashboard()
		return
	end

	status.Text = tostring(message)
	status.TextColor3 = COLORS.blueLight
	if screen.Enabled then
		return
	end

	local notified, notificationError = pcall(function()
		StarterGui:SetCore("SendNotification", {
			Title = "Nexus Moderation",
			Text = tostring(message),
			Duration = 6,
		})
	end)
	if not notified then
		warn("Nexus Admin: Could not display moderation notification: " .. tostring(notificationError))
	end
end)

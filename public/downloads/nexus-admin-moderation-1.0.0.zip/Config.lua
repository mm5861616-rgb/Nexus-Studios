local Config = {
	DataStoreName = "NexusAdminModeration_v1",
	GroupId = 0,
	MinimumGroupRank = 200,
	AdminUserIds = {},
	LogPageSize = 25,
	MaxWarningsPerUser = 50,
	ActionCooldownSeconds = 1,
	PanelToggleKey = Enum.KeyCode.RightShift,
}

return Config

# Nexus Admin & Moderation

Nexus Admin & Moderation is a Roblox Studio Luau resource for experience owners. It includes an in-game admin panel, `/commands`, `/admin`, `/kick`, `/ban`, `/unban`, and `/warn` chat commands, persistent bans and warnings, and a persistent moderation log.

The server script is authoritative: admin permissions, target rank checks, action validation, cooldowns, and DataStore changes happen on the server. Client remotes never grant moderation permissions. The package does not contain an external host, web service, or admin-account credentials.

## Features

- Authorize administrators by Roblox group rank, an explicit user ID allowlist, or both.
- Kick players currently in the server.
- Ban online or offline players by numeric Roblox user ID. Bans persist in DataStore and are checked at join.
- Unban by user ID.
- Save warnings for online or offline users, notify online players, and inspect warning history in the panel.
- Persist an audit log with action, moderator, target, reason, and UTC timestamp.
- Browse current players and recent moderation logs in the dark Nexus in-game panel. Press **Right Shift** to toggle it.
- Use TextChatService commands: `/commands`, `/admin`, `/kick`, `/ban`, `/unban`, and `/warn`.
- Protects equal- or higher-ranked group administrators from moderation. If an offline target's group rank cannot be checked, the action is denied.

## Requirements

- Roblox Studio experience with the modern `TextChatService`.
- DataStore API access. In Studio testing, publish the experience and enable **Game Settings → Security → Enable Studio Access to API Services**. Prefer a separate test experience; Studio uses the same DataStores as the published experience when access is enabled.
- Replace the example group ID or allowlist in `Config.lua` before publishing.

## Installation in Roblox Studio

Create this exact hierarchy:

```text
ServerScriptService
└── NexusAdminModeration (Folder)
    ├── Config (ModuleScript)          <- contents of Config.lua
    └── Server (Script)                <- contents of Server.server.lua

StarterPlayer
└── StarterPlayerScripts
    └── NexusAdminPanel (LocalScript)  <- contents of AdminPanel.client.lua
```

The server script creates `ReplicatedStorage.NexusAdminRemotes` and its remotes automatically. Do not create client-controlled remotes that perform moderation.

### Configure administrators

Edit the `Config` ModuleScript:

```lua
local Config = {
    DataStoreName = "NexusAdminModeration_v1",
    GroupId = 12345678, -- your Roblox group ID; use 0 to disable group authorization
    MinimumGroupRank = 200,
    AdminUserIds = {
        123456789, -- explicit Roblox user IDs; replace with your own
    },
    LogPageSize = 25,
    MaxWarningsPerUser = 50,
    ActionCooldownSeconds = 1,
    PanelToggleKey = Enum.KeyCode.RightShift,
}

return Config
```

- Set `GroupId` to your Roblox group and `MinimumGroupRank` to the lowest allowed moderator rank. Use `GroupId = 0` if you only want the explicit user ID allowlist.
- Add trusted numeric user IDs to `AdminUserIds`. Remove the example ID.
- Do not use display names or usernames as an authorization mechanism.
- Test with a non-admin account and a test group before publishing.

## Commands

| Command | Example | Description |
| --- | --- | --- |
| `/commands` | `/commands` | Sends the admin command list in a private notification or the open panel. |
| `/admin` | `/admin` | Opens the in-game panel using Right Shift. |
| `/kick` | `/kick 123456789 Repeated spam` | Kicks an online player by user ID. |
| `/ban` | `/ban 123456789 Exploiting` | Applies a persistent ban to an online or offline user ID. |
| `/unban` | `/unban 123456789 Appeal accepted` | Removes a persistent ban. |
| `/warn` | `/warn 123456789 Follow the rules` | Saves a warning and notifies the target if online. |

Commands use user IDs rather than names so a similarly named player cannot be mistaken for the intended target. In the panel, select an online player or enter a numeric user ID; the reason is optional.

## Data and moderation behavior

- Bans and warning histories are stored in DataStores named from `DataStoreName`. Moderation audit records and their ordered index use separate DataStores.
- If a ban record cannot be checked on join, the script warns in the server output and temporarily rejects that join rather than silently treating the player as unbanned.
- A successful moderation action reports when its audit log could not be persisted; inspect Studio/server output for the DataStore error.
- Bans are experience-wide across places using the same DataStore name.
- Warning history is capped to the newest `MaxWarningsPerUser` entries. Audit logs are retained in DataStore; the panel displays the newest `LogPageSize`.
- There is no automatic appeal workflow, ban expiry, warning expiry, or log deletion.

## Security notes

- Every admin remote call rechecks the caller's group/allowlist permissions on the server.
- Target IDs are validated on the server. For online targets, their group rank is compared to the acting moderator. Offline group targets are checked through Roblox's group service; if the check fails, moderation is denied.
- The server enforces an action cooldown and uses DataStore for persistent state. Never move the authority checks or datastore writes to the LocalScript.
- Do not add arbitrary `loadstring`, client-supplied rank, or client-authoritative permission values.

## Troubleshooting

- **Panel says permissions could not be verified:** check `Config.GroupId`, the group's rank settings, and the server output. The configured user ID allowlist remains available for trusted owners.
- **DataStore errors in Studio:** publish the test experience and enable Studio API access. Use a separate test DataStore name/environment.
- **Chat commands do not appear:** confirm the experience uses the modern `TextChatService` and that the scripts were placed in the exact services above.
- **Offline moderation is denied:** if a group ID is configured, Roblox's group-rank lookup must be available so the script can protect offline administrators.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local DataStoreService = game:GetService("DataStoreService")
local GroupService = game:GetService("GroupService")
local TextChatService = game:GetService("TextChatService")
local HttpService = game:GetService("HttpService")

local Config = require(script.Parent:WaitForChild("Config"))
local moderationStores = DataStoreService:GetDataStore(Config.DataStoreName .. "_Moderation")
local logStore = DataStoreService:GetDataStore(Config.DataStoreName .. "_Logs")
local logOrderStore = DataStoreService:GetOrderedDataStore(Config.DataStoreName .. "_LogOrder")

local remotes = ReplicatedStorage:FindFirstChild("NexusAdminRemotes")
if remotes and not remotes:IsA("Folder") then
	error("ReplicatedStorage.NexusAdminRemotes must be a Folder.")
end
if not remotes then
	remotes = Instance.new("Folder")
	remotes.Name = "NexusAdminRemotes"
	remotes.Parent = ReplicatedStorage
end
remotes:SetAttribute("PanelToggleKey", Config.PanelToggleKey.Name)

local adminRequest = remotes:FindFirstChild("AdminRequest")
if adminRequest and not adminRequest:IsA("RemoteFunction") then
	error("NexusAdminRemotes.AdminRequest must be a RemoteFunction.")
end
if not adminRequest then
	adminRequest = Instance.new("RemoteFunction")
	adminRequest.Name = "AdminRequest"
	adminRequest.Parent = remotes
end

local adminNotice = remotes:FindFirstChild("AdminNotice")
if adminNotice and not adminNotice:IsA("RemoteEvent") then
	error("NexusAdminRemotes.AdminNotice must be a RemoteEvent.")
end
if not adminNotice then
	adminNotice = Instance.new("RemoteEvent")
	adminNotice.Name = "AdminNotice"
	adminNotice.Parent = remotes
end

local lastActionAt = {}
local actionHandlers = {}

local function isConfiguredAdmin(userId)
	for _, allowedUserId in ipairs(Config.AdminUserIds) do
		if allowedUserId == userId then
			return true
		end
	end
	return false
end

local function getAdminRank(player)
	if isConfiguredAdmin(player.UserId) then
		return 256
	end
	if Config.GroupId <= 0 then
		return nil, "Set Config.GroupId or add your user ID to Config.AdminUserIds in Config."
	end

	local success, rankOrError = pcall(function()
		return player:GetRankInGroup(Config.GroupId)
	end)
	if not success then
		warn("Nexus Admin: Could not verify group permissions for " .. player.Name .. ": " .. tostring(rankOrError))
		return nil, "Admin permissions could not be verified. Try again later."
	end
	if rankOrError < Config.MinimumGroupRank then
		return nil, "You do not have permission to use the Nexus admin panel."
	end
	return rankOrError
end

local function getTargetRank(userId, target)
	if isConfiguredAdmin(userId) then
		return 256
	end
	if Config.GroupId <= 0 then
		return nil
	end

	if target then
		local success, rankOrError = pcall(function()
			return target:GetRankInGroup(Config.GroupId)
		end)
		if not success then
			warn("Nexus Admin: Could not verify group rank for target " .. tostring(userId) .. ": " .. tostring(rankOrError))
			return nil, "The target's group rank could not be verified, so this action was denied."
		end
		if rankOrError >= Config.MinimumGroupRank then
			return rankOrError
		end
		return nil
	end

	local groupsSuccess, groupsOrError = pcall(function()
		return GroupService:GetGroupsAsync(userId)
	end)
	if not groupsSuccess then
		warn("Nexus Admin: Could not verify group rank for offline target " .. tostring(userId) .. ": " .. tostring(groupsOrError))
		return nil, "The target's group rank could not be verified, so this action was denied."
	end
	for _, group in ipairs(groupsOrError) do
		if group.Id == Config.GroupId and group.Rank >= Config.MinimumGroupRank then
			return group.Rank
		end
	end
	return nil
end

local function checkTargetAuthority(actor, targetUserId)
	if actor.UserId == targetUserId then
		return false, "You cannot moderate your own account."
	end

	local target = Players:GetPlayerByUserId(targetUserId)
	local actorRank, actorError = getAdminRank(actor)
	if not actorRank then
		return false, actorError
	end

	local targetRank, targetRankError = getTargetRank(targetUserId, target)
	if targetRankError then
		return false, targetRankError
	end
	if targetRank and actorRank <= targetRank then
		return false, "You cannot moderate an admin with an equal or higher group rank."
	end
	return true
end

local function getTargetUserId(rawValue)
	local userId = tonumber(rawValue)
	if not userId or userId <= 0 or userId % 1 ~= 0 then
		return nil
	end
	return userId
end

local function normalizeReason(rawReason)
	if typeof(rawReason) ~= "string" then
		return "No reason provided"
	end
	local reason = string.sub(string.gsub(rawReason, "[\r\n]", " "), 1, 300)
	if string.match(reason, "^%s*$") then
		return "No reason provided"
	end
	return reason
end

local function getUserDisplayName(userId)
	local player = Players:GetPlayerByUserId(userId)
	if player then
		return player.Name
	end
	return "UserId " .. tostring(userId)
end

local function appendLog(entry)
	entry.id = HttpService:GenerateGUID(false)
	entry.timestamp = DateTime.now().UnixTimestampMillis
	local key = entry.id

	local payloadSaved, payloadError = pcall(function()
		logStore:SetAsync(key, entry)
	end)
	if not payloadSaved then
		return false, "Moderation action completed, but its log could not be saved: " .. tostring(payloadError)
	end

	local indexSaved, indexError = pcall(function()
		logOrderStore:SetAsync(key, entry.timestamp)
	end)
	if not indexSaved then
		warn("Nexus Admin: Log entry " .. key .. " was saved without its index: " .. tostring(indexError))
		return false, "Moderation action completed, but the log index could not be saved."
	end
	return true
end

local function recordAction(actor, action, targetUserId, reason)
	local saved, logError = appendLog({
		action = action,
		actorUserId = actor.UserId,
		actorName = actor.Name,
		targetUserId = targetUserId,
		targetName = getUserDisplayName(targetUserId),
		reason = reason,
	})
	if not saved then
		return " " .. logError
	end
	return ""
end

local function ensureActionCooldown(player)
	local now = os.clock()
	local previous = lastActionAt[player.UserId] or 0
	if now - previous < Config.ActionCooldownSeconds then
		return false
	end
	lastActionAt[player.UserId] = now
	return true
end

local function warnPlayer(targetUserId, reason)
	local key = "warnings_" .. tostring(targetUserId)
	local updatedWarnings
	local success, updateError = pcall(function()
		updatedWarnings = moderationStores:UpdateAsync(key, function(currentWarnings)
			local warnings = if typeof(currentWarnings) == "table" then currentWarnings else {}
			table.insert(warnings, {
				reason = reason,
				timestamp = DateTime.now().UnixTimestampMillis,
			})
			while #warnings > Config.MaxWarningsPerUser do
				table.remove(warnings, 1)
			end
			return warnings
		end)
	end)
	if not success then
		return false, "Warning could not be saved: " .. tostring(updateError)
	end

	local target = Players:GetPlayerByUserId(targetUserId)
	if target then
		adminNotice:FireClient(target, "You received a moderator warning: " .. reason)
	end
	return true, "Warning saved. Total warnings: " .. tostring(#updatedWarnings) .. "."
end

actionHandlers.Kick = function(actor, payload)
	local userId = getTargetUserId(payload.targetUserId)
	if not userId then
		return false, "Enter a valid numeric Roblox user ID."
	end
	local allowed, authorityError = checkTargetAuthority(actor, userId)
	if not allowed then
		return false, authorityError
	end

	local target = Players:GetPlayerByUserId(userId)
	if not target then
		return false, "Kick only works for a player currently in this server."
	end
	local reason = normalizeReason(payload.reason)
	local kicked, kickError = pcall(function()
		target:Kick("Removed by a moderator: " .. reason)
	end)
	if not kicked then
		return false, "Kick failed: " .. tostring(kickError)
	end
	return true, "Player kicked." .. recordAction(actor, "Kick", userId, reason)
end

actionHandlers.Ban = function(actor, payload)
	local userId = getTargetUserId(payload.targetUserId)
	if not userId then
		return false, "Enter a valid numeric Roblox user ID."
	end
	local allowed, authorityError = checkTargetAuthority(actor, userId)
	if not allowed then
		return false, authorityError
	end

	local reason = normalizeReason(payload.reason)
	local saved, saveError = pcall(function()
		moderationStores:SetAsync("ban_" .. tostring(userId), {
			reason = reason,
			actorUserId = actor.UserId,
			actorName = actor.Name,
			timestamp = DateTime.now().UnixTimestampMillis,
		})
	end)
	if not saved then
		return false, "Ban was not applied because it could not be saved: " .. tostring(saveError)
	end

	local target = Players:GetPlayerByUserId(userId)
	local kickFailure
	if target then
		local kicked, kickError = pcall(function()
			target:Kick("Banned from this experience: " .. reason)
		end)
		if not kicked then
			kickFailure = " The ban is saved, but the online player could not be disconnected: " .. tostring(kickError)
		end
	end
	return true, "Persistent ban saved." .. (kickFailure or "") .. recordAction(actor, "Ban", userId, reason)
end

actionHandlers.Unban = function(actor, payload)
	local userId = getTargetUserId(payload.targetUserId)
	if not userId then
		return false, "Enter a valid numeric Roblox user ID."
	end
	local allowed, authorityError = checkTargetAuthority(actor, userId)
	if not allowed then
		return false, authorityError
	end

	local removed, removeError = pcall(function()
		moderationStores:RemoveAsync("ban_" .. tostring(userId))
	end)
	if not removed then
		return false, "Unban failed: " .. tostring(removeError)
	end
	return true, "Ban removed." .. recordAction(actor, "Unban", userId, normalizeReason(payload.reason))
end

actionHandlers.Warn = function(actor, payload)
	local userId = getTargetUserId(payload.targetUserId)
	if not userId then
		return false, "Enter a valid numeric Roblox user ID."
	end
	local allowed, authorityError = checkTargetAuthority(actor, userId)
	if not allowed then
		return false, authorityError
	end

	local reason = normalizeReason(payload.reason)
	local saved, warningMessage = warnPlayer(userId, reason)
	if not saved then
		return false, warningMessage
	end
	return true, warningMessage .. recordAction(actor, "Warn", userId, reason)
end

local function getRecentLogs()
	local pages = logOrderStore:GetSortedAsync(false, math.clamp(Config.LogPageSize, 1, 50))
	local results = {}
	for _, item in ipairs(pages:GetCurrentPage()) do
		local entry = logStore:GetAsync(item.key)
		if entry then
			table.insert(results, entry)
		end
	end
	return results
end

local function getDashboardData()
	local playerList = {}
	for _, player in ipairs(Players:GetPlayers()) do
		table.insert(playerList, {
			userId = player.UserId,
			name = player.Name,
			displayName = player.DisplayName,
		})
	end
	table.sort(playerList, function(a, b)
		return string.lower(a.name) < string.lower(b.name)
	end)
	return {
		players = playerList,
		logs = getRecentLogs(),
	}
end

adminRequest.OnServerInvoke = function(player, request)
	local rank, permissionError = getAdminRank(player)
	if not rank then
		return { ok = false, error = permissionError }
	end
	if typeof(request) ~= "table" then
		return { ok = false, error = "Invalid admin request." }
	end

	if request.type == "GetDashboard" then
		local success, dashboardOrError = pcall(getDashboardData)
		if not success then
			warn("Nexus Admin: Dashboard data request failed for " .. player.Name .. ": " .. tostring(dashboardOrError))
			return { ok = false, error = "Dashboard data could not be loaded. Check DataStore access and server logs." }
		end
		return { ok = true, data = dashboardOrError }
	end

	if request.type == "Action" then
		if not ensureActionCooldown(player) then
			return { ok = false, error = "Please wait before running another moderation action." }
		end
		if typeof(request.action) ~= "string" or typeof(request.payload) ~= "table" then
			return { ok = false, error = "Invalid moderation action." }
		end
		local handler = actionHandlers[request.action]
		if not handler then
			return { ok = false, error = "Unknown moderation action." }
		end

		local success, resultOrError, detail = pcall(handler, player, request.payload)
		if not success then
			warn("Nexus Admin: " .. tostring(request.action) .. " failed for " .. player.Name .. ": " .. tostring(resultOrError))
			return { ok = false, error = "Moderation action failed. Check the server log and DataStore access." }
		end
		return { ok = resultOrError, message = detail or resultOrError }
	end

	if request.type == "GetWarnings" then
		local targetUserId = getTargetUserId(request.targetUserId)
		if not targetUserId then
			return { ok = false, error = "Enter a valid numeric Roblox user ID." }
		end
		local allowed, authorityError = checkTargetAuthority(player, targetUserId)
		if not allowed then
			return { ok = false, error = authorityError }
		end
		local success, warningsOrError = pcall(function()
			return moderationStores:GetAsync("warnings_" .. tostring(targetUserId))
		end)
		if not success then
			warn("Nexus Admin: Warning history request failed for " .. tostring(targetUserId) .. ": " .. tostring(warningsOrError))
			return { ok = false, error = "Warning history could not be loaded. Check DataStore access." }
		end
		return { ok = true, warnings = if typeof(warningsOrError) == "table" then warningsOrError else {} }
	end

	return { ok = false, error = "Unknown admin request." }
end

local function checkJoinBan(player)
	local success, banData = pcall(function()
		return moderationStores:GetAsync("ban_" .. tostring(player.UserId))
	end)
	if not success then
		warn("Nexus Admin: Ban status could not be verified for " .. player.Name .. ": " .. tostring(banData))
		player:Kick("Ban status could not be verified. Please try joining again later.")
		return
	end
	if typeof(banData) == "table" then
		player:Kick("Banned from this experience: " .. normalizeReason(banData.reason))
	end
end

Players.PlayerAdded:Connect(function(player)
	task.spawn(checkJoinBan, player)
end)

Players.PlayerRemoving:Connect(function(player)
	lastActionAt[player.UserId] = nil
end)

for _, player in ipairs(Players:GetPlayers()) do
	task.spawn(checkJoinBan, player)
end

local function runChatAction(player, action, userIdText, reasonText)
	local rank, permissionError = getAdminRank(player)
	if not rank then
		warn("Nexus Admin: Rejected chat command from " .. player.Name .. ": " .. tostring(permissionError))
		return
	end
	if not ensureActionCooldown(player) then
		return
	end
	local handler = actionHandlers[action]
	if not handler then
		return
	end
	local success, actionSucceeded, result = pcall(handler, player, {
		targetUserId = userIdText,
		reason = reasonText,
	})
	if not success then
		warn("Nexus Admin: Chat command failed for " .. player.Name .. ": " .. tostring(actionSucceeded))
	elseif not actionSucceeded then
		warn("Nexus Admin: Chat command rejected for " .. player.Name .. ": " .. tostring(result))
	end
end

local chatCommands = {
	{ name = "NexusCommands", alias = "/commands", action = "Help" },
	{ name = "NexusKick", alias = "/kick", action = "Kick" },
	{ name = "NexusBan", alias = "/ban", action = "Ban" },
	{ name = "NexusUnban", alias = "/unban", action = "Unban" },
	{ name = "NexusWarn", alias = "/warn", action = "Warn" },
	{ name = "NexusPanel", alias = "/admin", action = "Panel" },
}

for _, definition in ipairs(chatCommands) do
	local command = TextChatService:FindFirstChild(definition.name) or Instance.new("TextChatCommand")
	command.Name = definition.name
	command.PrimaryAlias = definition.alias
	command.Parent = TextChatService
	command.Triggered:Connect(function(textSource, unfilteredText)
		local player = Players:GetPlayerByUserId(textSource.UserId)
		if not player then
			return
		end
		if definition.action == "Help" then
			local rank = getAdminRank(player)
			if rank then
				adminNotice:FireClient(player, "Commands: /admin, /kick userId reason, /ban userId reason, /unban userId reason, /warn userId reason.")
			end
			return
		end
		if definition.action == "Panel" then
			local rank = getAdminRank(player)
			if rank then
				adminNotice:FireClient(player, "OPEN_PANEL")
			end
			return
		end

		local userIdText, reasonText = string.match(unfilteredText, "^%S+%s+(%d+)%s*(.*)$")
		if not userIdText then
			adminNotice:FireClient(player, "Usage: " .. definition.alias .. " userId reason")
			return
		end
		runChatAction(player, definition.action, userIdText, reasonText)
	end)
end
